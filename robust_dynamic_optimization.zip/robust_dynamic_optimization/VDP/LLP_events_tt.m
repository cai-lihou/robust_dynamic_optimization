function [Gmax,Tmax] = LLP_events_tt(u,~,P_UBD)
global T N x0 
p_num = numel(P_UBD);
Init_val_sensi_equ = zeros(1, 3*N*p_num); %3 is the dimension of system, need to intialize the senstivity equs
x=[0 1 0]; 
y=repmat(x,1,p_num);
y0=[y Init_val_sensi_equ];
% for j=1:p_num
%     P_1{j}=P_UBD(j,:);
%     T_UBD{j}=P_1{j}(1,2:end);
% end
%index=1:3:3*p_num;
%y1=y0(index);
%Gmax1= -y1-0.4;
tt=[];
tt_1=[];
state=[];
state_1=[];
for i=1:N
    
        [t,x]=ode45(@(t,x)defineode(t,x,u(i),i,p_num),[(i-1)*T/(N),i*T/(N)],y0);
        y0=x(end,:);
        x_all=[state_1;x];
        t_all=[tt_1;t];
        state_1=x_all;
        tt_1= t_all;
  
end

G=-x_all-0.4;
for i=1:p_num
    g=G(:,3*i-2);
    p=find(g==max(g));
    index=p(1,1);
    Gmax(i)=g(index);
    Tmax(i)=t_all(index);
end







% for j=1:p_num
%     g{j}=-x_all(:,3*j-2)-0.4;
%     p{j}=find(g{j}==max(g{j}));
%     index=p{j}(1,1);
% %     index_p=cell2mat(p{j});
% %     if numel(index_p)~=1
% %         index_pp=index_p(1);
% %     end
%     index_p(j)=index;
% %     if sum(sum(~cellfun(@isempty,p{j})))~=1
% %         p(j)=p{j}(1);
% %     end
% end

%g=-x_all(:,index)-0.4;
figure (12)
hold on
box on


for j=1:p_num
plot(t_all,G(:,3*j-2),'b','linewidth',2)
%text( Tmax(j),Gmax(j),'*','color','r')
plot(Tmax(j),Gmax(j),'p','Markersize',9,'MarkerFaceColor','r')
%Gmax(j)=g{j}(index_p(j));
%Tmax(j)=t_all(index_p(j));
end

plot(t_all,x_all(:,1)-x_all(:,1),'m--');



end