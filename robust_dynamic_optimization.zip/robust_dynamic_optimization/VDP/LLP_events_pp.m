function [gpmax, Best_fsb_sulotion] = LLP_events_pp(u)

Var_bound_L=[0.9];Var_bound_U=[1.1];
u_best=[-0.275078716878369;-0.0110667286885058;0.233554801511462;0.458180199248772;0.662142824562986;0.844891467460967;0.956603823056771;0.944181784312811;0.931511067591762;0.915467252529032;0.900787433998564;0.884277556588070;0.866745340839420;0.849490860436414;0.822753669503603;0.818163014117129;0.764626380843900;0.774418136309479;0.772862381596858;0.761562791092166;0.742059447471359;0.715802453087715;0.684134957254055;0.648285227165985;0.609360173246312;0.568345266406453;0.526104563964380;0.483390534459431;0.440845881164115;0.399012783223236;0.358344526487607;0.319210476108113;0.281906218957839;0.246661471497909;0.213649156410010;0.182990904573916;0.154765703189688;0.129016761374872;0.105755195296276;0.0849662244896810;0.0666146481375897;0.0506481360701255;0.0370009386148527;0.0255976888222897;0.0163549619702282;0.00918441830260789;0.00399445272703128;0.000691371427773345;-0.000819771205773230;-0.000634472604864030];

u_conpare=[-0.200886204833169;0.0268596049486478;0.241136395592859;0.439792211565266;0.621150472396027;0.784114479259101;0.928196390300259;0.938337251352289;0.922819477373557;0.906028735465501;0.887964822722975;0.875339891664963;0.834182674564485;0.833324417167455;0.802973260644384;0.807960139115526;0.820395090781330;0.820590110450454;0.810218133904311;0.790904564002579;0.764188911624640;0.731510414245506;0.694188107117000;0.653415678154146;0.610262064809123;0.565663689885058;0.520439065427870;0.475287909532341;0.430803797956770;0.387481504478884;0.345724671891054;0.305858459343656;0.268136390474151;0.232748989475894;0.199831992737864;0.169473882321560;0.141724003210911;0.116596547756856;0.0940779000573257;0.0741307128358034;0.0566998123297262;0.0417149565386324;0.0290939909852629;0.0187483171262381;0.0105807513345720;0.00449172180433361;0.000379698699571853;-0.00185890402150399;-0.00232718411920938;-0.00112866284763841];
%����ʦ�ĶԱ�ͼ��  cvp50��
Initial_rgn = [0.9,1.1];
Node{1} = Initial_rgn;
Width_Node0 = Initial_rgn(:,end) - Initial_rgn(:,1) ;
Lower_Bound = -inf;
Upper_Bound = inf;
%Upperbound_Nodes = [];
Lowerbound_Nodes = [];
Bound_Tol = 0.0000001; %%�ݲ�
Iteration = 0;
Rcd_Node = cell(500,200);


global T N x0 Dms_p

%u=[0.5,0.1,0.7,1,0.6,0.1,0.8,1,0.7,1];
% p0 = 0;      %initialized the u0
 T=5;           %total time
 N=50;           %total number of decision variables, works for N=15, r=1.7, epsilon_g0=50, Tubd=1
 Init_val_sensi_equ = zeros(1, 3); %3 is the dimension of system, need to intialize the senstivity equs
 x0=[0 1 0 Init_val_sensi_equ]; 
 Dms_p=1;

[opt, fmin_Prml_U, exitflag,~,~,~] = solve_local(u,[Node{1}]);
if exitflag == -2
    Upper_Bound = inf;
else
    Best_fsb_sulotion = opt;
    Upper_Bound = fmin_Prml_U;
end

[~,fmin_Prml_L,~,~,~,~] = solve_low(u,Node{1});
Lower_Bound = fmin_Prml_L;
Lowerbound_Nodes = [Lowerbound_Nodes fmin_Prml_L];
while(1)
 %��ֹ���� 
    if numel(Node) == 0
        disp("�ڵ���Ϊ��");
        break
    end
    if Upper_Bound == inf
         disp("ԭ���ⲻ����");
         break
    end
	if Upper_Bound - Lower_Bound <= Bound_Tol
         disp("���½��ֽӽ�");
         break
    end
    
    %Step3  ѡ��ڵ�  
    Num_Nodes = numel(Node);
    [~,c_No] = min(Lowerbound_Nodes);
    %c_No = ceil(Num_Nodes*rand(1));
    Current_Node = Node(c_No);
    Node(c_No) = [];
    Lowerbound_Nodes(c_No) = [];
    
	%Step4 ��֧
    c_nod = cell2mat(Current_Node);
    Width_Curtnd = c_nod(:,end) - c_nod(:,1);
    [~, Lest_rdu_aixs] = max(Width_Curtnd./Width_Node0);Dmsn = numel(c_nod(:,1));
    Shift_vector = zeros(Dmsn,1);
    Shift_vector(Lest_rdu_aixs,1) = Width_Curtnd(Lest_rdu_aixs)*0.5;
    New_node{1} = c_nod - [zeros(Dmsn,1) Shift_vector];
    New_node{2} = c_nod + [Shift_vector zeros(Dmsn,1)];
    
    
    %Step5 ����ڵ�ֲ��� �����Ͻ� ��ɾ����Ч�ڵ�
    LocalFsbSol_New_node = cell(0);
    LocalFmin_New_node = [];
    for i = 1:2
        [opt, fmin, exitflag,~,~,~] = solve_local(u,New_node{i});
        if exitflag ~= -2
            LocalFsbSol_New_node = [LocalFsbSol_New_node opt];
            LocalFmin_New_node = [LocalFmin_New_node fmin];
        end
    end   
    if min([LocalFmin_New_node Upper_Bound]) ~= Upper_Bound
        [Upper_Bound, I] = min([LocalFmin_New_node Upper_Bound]);
        Best_fsb_sulotion = LocalFsbSol_New_node{I};
    end
    for i = 1:numel(Node)
        if Lowerbound_Nodes(i) > Upper_Bound
            Node(i) = [];
            Lowerbound_Nodes(i) = [];
        end
    end
    
    %Step6 ����ڵ��½� �����½� ������Ч�ڵ�
	Lower_New_node = [-inf -inf];
    for i = 1:2
        [~,fmin_lower, exitflag,~,~,~] = solve_low(u,New_node{i});
        %Lower_New_node(i) = fmin_lower;
        if exitflag ~= -2
            Lower_New_node(i) = fmin_lower;
        end
    end    
    
	for i = 1:2
        if Lower_New_node(i) < Lower_Bound
            Lower_New_node(i) = Lower_Bound;
        end
        if Lower_New_node(i) <= Upper_Bound
            Node = [Node, New_node{i}];
            Lowerbound_Nodes = [Lowerbound_Nodes, Lower_New_node(i)];
        end
	end
    
    Lower_Bound = min(Lowerbound_Nodes);
    
	Iteration = Iteration + 1;
    
    Rcd_Node(Iteration,1:numel(Node)) = Node;
end
gpmax=-Lower_Bound;
end
