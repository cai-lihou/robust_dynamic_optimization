
function [decvar, fmin, inf_flag,output, LAMBDA,cost_grad] = upperbounding(P_UBD,T_UBD,epislon_g)
options = optimset('GradConstr','on','Algorithm','sqp','MaxFunEvals',10000); 

%  options = optimset('GradConstr','on','Algorithm','sqp','MaxFunEvals',10000,'Display','iter','PlotFcns',{@optimplotfirstorderopt,@optimplotfval,@optimplotfunccount,@optimplotx...
%      }); 
 global N  u0 newu0    iter   %N is the number of decison variables, u0 is intial values
                      %of decison variables
 global u_lb u_ub 
 U0 = zeros(N, 1);  %N by 1 array to store initial values of decision variables 
 LB = zeros(N, 1);  %N by 1 array to store lower bounds of decision variables 
 UB = zeros(N, 1);  %N by 1 array to store upper bounds of decision variables 
 for i=1:N
     if iter<1
     U0(i,1) = u0;  %initialize values of decision variables  ||||u0 = 0.5;
     else
   U0(i,1) = newu0(i);%����������
   %     U0(i,1) = u0;%������������
      end
     LB(i,1) = u_lb;  %set lower bounds of decision variables  
     UB(i,1) = u_ub;  %set upper bounds of decision variables
 end
 [X, FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD] = fmincon(@costfunction,U0,[],[],[],[],LB,UB,@(u)pathconstraints(u,P_UBD,T_UBD,epislon_g),options);
newu0=X;
decvar=X;      
fmin=FVAL;       
inf_flag=EXITFLAG; 
output=OUTPUT;   
cost_grad=GRAD;    
                  
end



