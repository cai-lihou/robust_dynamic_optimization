
clear all %clear exiting data
clc  %clear screen
H = cputime;
global T N x0 %define the global variables where T is total time considered,and N 
                 %is the number of decision variables %x0 is initial value of sates,
                 %u0 is initial value of control
global u_lb u_ub u0 newu0  iter P_UBD T_UBD %lower and upper bounds of control

global PFS       %PFS stands for parameter for sentivity equations
%u_best=[0.956603823056771;0.944181784312811;0.931511067591762;0.915467252529032;0.900787433998564;0.884277556588070;0.866745340839420;0.849490860436414;0.822753669503603;0.818163014117129;0.764626380843900;0.774418136309479;0.772862381596858;0.761562791092166;0.742059447471359;0.715802453087715;0.684134957254055;0.648285227165985;0.609360173246312;0.568345266406453;0.526104563964380;0.483390534459431;0.440845881164115;0.399012783223236;0.358344526487607;0.319210476108113;0.281906218957839;0.246661471497909;0.213649156410010;0.182990904573916;0.154765703189688;0.129016761374872;0.105755195296276;0.0849662244896810;0.0666146481375897;0.0506481360701255;0.0370009386148527;0.0255976888222897;0.0163549619702282;0.00918441830260789;0.00399445272703128;0.000691371427773345;-0.000819771205773230;-0.000634472604864030]
%uu=[-0.275078716878369;-0.0110667286885058;0.233554801511462;0.458180199248772;0.662142824562986;0.844891467460967;0.956603823056771;0.944181784312811;0.931511067591762;0.915467252529032;0.900787433998564;0.884277556588070;0.866745340839420;0.849490860436414;0.822753669503603;0.818163014117129;0.764626380843900;0.774418136309479;0.772862381596858;0.761562791092166;0.742059447471359;0.715802453087715;0.684134957254055;0.648285227165985;0.609360173246312;0.568345266406453;0.526104563964380;0.483390534459431;0.440845881164115;0.399012783223236;0.358344526487607;0.319210476108113;0.281906218957839;0.246661471497909;0.213649156410010;0.182990904573916;0.154765703189688;0.129016761374872;0.105755195296276;0.0849662244896810;0.0666146481375897;0.0506481360701255;0.0370009386148527;0.0255976888222897;0.0163549619702282;0.00918441830260789;0.00399445272703128;0.000691371427773345;-0.000819771205773230;-0.000634472604864030];

u0 = 0.5;      %initialized the u0
 T=5;           %total time
 N=50;          
 %% x0��ֵ����
 T_UBD=[5];
 P_UBD=[1];
p_num=numel(P_UBD);
  Init_val_sensi_equ = zeros(1, 3*N*p_num); 
  x=[0 1 0]; 
  y=repmat(x,1,p_num);
y0=[y Init_val_sensi_equ];
x0=y0;
 %Init_val_sensi_equ = zeros(1, 3*N); %3 is the dimension of system, need to intialize the senstivity equs
 %x0=[0 1 0 Init_val_sensi_equ]; 
 u_lb = -0.3;  %lower bounds of the decsion variables
 u_ub = 1;     %upper bounds of the decsion variables
 
 iter=0;               %p is number of iterations
 %r=[1.1 1.3 1.6 2 2.5 3 4 5.2 6.5 7.8 10 12 15 20]%
 r=4;
% r = 4;          %a parameter to control how quickly \epislon is decreased
 % iter=[1.03;88 1.1;40 1.3;30 1.6;31 2;25 2.4;32 3;28 4;23   5;   5.2;34  6;31  6.5;27   7;32   7.8;43  10;47  12;52 15;47 20;64]
 epsilon_act=1e-3;  %active tolerance
 epsilon_sat=1e-3;  %stationary tolerance,i.e, KKT error
 epislon_g0 = 0.001;    %initial value of restriction parameter
 
 
 
%% ȱ��Pud��ֵ 
 
%T_UBD1 = [5];  %finite set of parameter variable of T_UBD
 epislon_g = epislon_g0;  %restriction parameter  
[decvar, fmin, flag_inf, output,lambda,cost_grad] = upperbounding(P_UBD,T_UBD, epislon_g); %solve the UBD  
%% 
    c=-1; 
while c<=0    %enter the loop
      c=-1;   %start
      
 %%  ���ⲻ����   
   if flag_inf == -2 %if the UBD is infeasible
      epislon_g = epislon_g/r; % decrease the restriction parameter to make 
                               % the UBD feasible 
      c=-5;                    %c=-5 means to solve the UBD with the updated 
                        % restriction parameter (see the bottom of the while loop)
   end
  
%% �������
   if c==-1              %the UBD is feasible 
      u_bar = decvar;  %set u_bar equal to the returned minimizer point
           % count the valid iterations
%       [gmax, tmax] = LLP(u_bar,p);%solve the LLP globally which returns
%                                   %the maximum objective solution value and
%                                   %the first maximizer (if more than one)
%% ���ж�gmax�Ƿ�����㣬���ж�gpmax�����ȱ�֤һ��·��Լ�������㣬�ٱ�֤����·��Լ���ĵ�����
      [Gmax, Tmax]= LLP_events_tt(u_bar,iter,P_UBD); %Gmax��Tmax������
       index=find(Gmax>0);%�ҳ��ĸ�p��Ӧ�Ĵ���0
       if numel(index)==0  %ÿ��·��Լ��������
      %% ÿ��·��Լ������Υ�����ȼ���KKT�����Ƿ����㣬ֱ��kKT�������㣬��ȥ���ȫ��pmax     
                 cost_gradient_PCDP = cost_grad; % cost gradient of PCDP from UBD
         multi_PCDP = lambda.ineqnonlin; % Multilplers of PCDP from UBD
         [d, ceq, Gc, Gceq] = pathconstraints(decvar,P_UBD,T_UBD,epislon_g); %d is a set of nonlinear constraints at all elements in T_UBD
          %ceq is nonlienar equality, Gc is inequality gradients of d wrt decision variables, Gceq is equality gradients
         h = numel(d); %calculate number of constraints
         d1=[d(1:h-2*N)-epislon_g d(h-2*N+1:h)]; % need to subtract epislon_g from d(1:h-2) but bounds are ok, since d=g+\epislon_g
         m =0; %intermidate variable
         for j=1:h
             if multi_PCDP(j)*d1(j)<-multi_PCDP(j)*epsilon_act  
             %if multi_PCDP(j)*d(j)<-multi_PCDP(j)*epsilon_act 
                 %complementary slackness does not hold, i.e., \lamba*g
                 %<-\lamba*\epsilon_act
                 epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
                 c=-5; %solve the UBD with updated epislon_g
             else
                 % complementary slackness holds
                 m=m+1; %to see how many inequalities of compementary slackness condition hold, if m==h, meaning compementary slackness holds
             end
         end
 
         if ((m==h)&&(norm(cost_gradient_PCDP+Gc*multi_PCDP)<=epsilon_sat))==1  % %theoretically no need to verify stationary equation,but practically need
             u_local=u_bar; %obtained local minimizer and local o
             f_local=fmin;
             c=3;%%break
         else
             epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
             c=-5; 
         end
         
         
         
%% ���·��Լ���������أ�
      else %���е�·��Լ����Υ��
          T_UBD=[T_UBD Tmax(index)];
%        for i=index
%            P=P_UBD(i,:);
%            num = sum(sum(~cellfun(@isempty,P)));
%            P_UBD{i,num+1}=Tmax(i);
%                   
%        end
 c=-4; 
       end 
       
       %% ·��Լ����صĽ�������ʼp���
           
          if c==3 %����·��Լ����KKT������������
              
           
            [g_pmax, p_max] = LLP_events_pp(u_bar);
          
                  if g_pmax<= 0     %PCDP feasible 
         cost_gradient_PCDP = cost_grad; % cost gradient of PCDP from UBD
         multi_PCDP = lambda.ineqnonlin; % Multilplers of PCDP from UBD
         [d, ceq, Gc, Gceq] = pathconstraints(decvar,P_UBD,T_UBD,epislon_g); %d is a set of nonlinear constraints at all elements in T_UBD
          %ceq is nonlienar equality, Gc is inequality gradients of d wrt decision variables, Gceq is equality gradients
         h = numel(d); %calculate number of constraints
         d1=[d(1:h-2*N)-epislon_g d(h-2*N+1:h)]; % need to subtract epislon_g from d(1:h-2) but bounds are ok, since d=g+\epislon_g
         m =0; %intermidate variable
         for j=1:h
             if multi_PCDP(j)*d1(j)<-multi_PCDP(j)*epsilon_act  
             %if multi_PCDP(j)*d(j)<-multi_PCDP(j)*epsilon_act 
                 %complementary slackness does not hold, i.e., \lamba*g
                 %<-\lamba*\epsilon_act
                 epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
                 c=-5; %solve the UBD with updated epislon_g
             else
                 % complementary slackness holds
                 m=m+1; %to see how many inequalities of compementary slackness condition hold, if m==h, meaning compementary slackness holds
             end
         end
 
         if ((m==h)&&(norm(cost_gradient_PCDP+Gc*multi_PCDP)<=epsilon_sat))==1  % %theoretically no need to verify stationary equation,but practically need
             u_local=u_bar; %obtained local minimizer and local o
             f_local=fmin;
             c=3;%%break
         else
             epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
             c=-5; 
         end
            
                  end
       
     
               if g_pmax> 0         %UBD is feasible but u_bar is infeasible to PCDP
                   iter=iter+1 ;   
                   iter_norm=iter;
                   fmin_norm=fmin;
                   T_UBD=[5];
           epislon_g=epislon_g/r; 
           P_UBD= [P_UBD;p_max]; %populate the T_UBD to exclude u_bar
           c=-4;              %c=-5 means to solve the UBD with the populated T_UBD  
           P_UBD;
%            P_0=P_UBD(:,1);
%            p_num = sum(sum(~cellfun(@isempty,P_0)));
             p_num=numel(P_UBD);
            Init_val_sensi_equ = zeros(1, 3*N*p_num); 

           x=[0 1 0]; 
           y=repmat(x,1,p_num);
           y0=[y Init_val_sensi_equ];
           x0=y0;
           
%        P1=P_UBD(:,1);
%        P2=cell(20,30);
%        P3=P2(:,2:end);
%        P_UBD=[P1,P3];
     end     
                  
                  
                  
                        
%        else %���е�·��Լ����Υ��
%        for i=index
%            P=P_UBD(i,:);
%            num = sum(sum(~cellfun(@isempty,P)));
%            P_UBD{i,num+1}=Tmax(i);
%                    c=-4; 
%        end
           
%a=p(1,:)
%num = sum(sum(~cellfun(@isempty,a)))
           
          end
       end

    

  

    %%
    if (c==-5 || c==-4)==1   %for reduce restriction parameter or populted T_UBD
        
        [decvar, fmin, flag_inf, output,lambda,cost_grad] = upperbounding(P_UBD,T_UBD, epislon_g); 
        epislon_g;
          iter=iter+1 ;  
              %solving UBD with either populated T_UBD or reduced epislon_g 
              iter
              T_UBD
              P_UBD
    end
end %end of flow control for feasibility of UBD
   
iter_robust=iter;

f_local   %displace the resulting local optimal solution value
u_local   %displace the resulting local minimizer
iter_robust
iter_norm
TIME = cputime-H  %cup time
% gmax              %output final gmax
% p
% epislon_g
% T_UBD



                