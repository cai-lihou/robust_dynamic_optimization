%%%����SQP�㷨�������Թ滮��Ҫ��Ŀ�꺯���Կ�����U���ݶȣ�����Ҫ״̬���̺������ȷ���
function dx=defineode(t,x,u,pfs,b)%Ŀ�꺯������״̬���̣������ȡ�nonlinear and dynamic optimization ��169ҳ
% State and Sensitivity Numerical Integration״̬����������ֵ���

% dx = [u; 1];  %original ode is x_dot =u, the sensitive equation dx/du =1 with initial value 0
global N P_UBD x0
%% �ж��ٸ�pmax����Ӧ������ode����
dx = zeros(b*(3+3*N),1);
y0=x0;  %pass the intial value of states
% PP_0=P_UBD(:,1);
% P_0=cell2mat(PP_0);
% dx(1)=(1-x(2)^2)*x(1)-x(2)+u; %system state equs                                        
% dx(2) = x(1); 
% dx(3)= x(1)^2+x(2)^2+u^2;
%% ���óɲ�ͬ����� ����������ʵ�����case

switch b
    case 1
                        
dx(1)=(1-x(2)^2)*x(1)-x(2)+u; %system state equs                                        
dx(2) = x(1); 
dx(3)= x(1)^2+x(2)^2+u^2;
for i=1:N
    if i==pfs  
% for j=1:b
%     dx(3*j-2)=(1-x(3*j-1)^2)*x(3*j-2)-x(3*j-1)+u;
%     dx(3*j-1)=P_UBD(j)*x(3*j-2);
%     dx(3*j)=x(3*j-2)^2+x(3*j-1)^2+u^2;
% end
    dx(3*i+1)=(1-x(2)^2)*x(3*i+1)+(-2*x(1)*x(2)-1)*x(3*i+2)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(3*i+2)=1*x(3*i+1);     
    dx(3*i+3)=(2*x(1))*x(3*i+1)+(2*x(2))*x(3*i+2)+2*u;  
    else
    dx(3*i+1)=(1-x(2)^2)*x(3*i+1)+(-2*x(1)*x(2)-1)*x(3*i+2);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(3*i+2)=1*x(3*i+1);     
    dx(3*i+3)=(2*x(1))*x(3*i+1)+(2*x(2))*x(3*i+2);  
    end
end

    case 2
       
dx(1)=(1-x(2)^2)*x(1)-x(2)+u; %system state equs                                        
dx(2) = x(1); 
dx(3)= x(1)^2+x(2)^2+u^2;




dx(4)=(1-x(5)^2)*x(4)-x(5)+u; %system state equs                                        
dx(5) = P_UBD(2)*x(4); 
dx(6)= x(4)^2+x(5)^2+u^2;
for i=1:N
    if i==pfs  %p��pathconstraints�е�PFS��Ҳ����ÿһ�ηֶ�i=1��N
    dx(6*i+1)=(1-x(2)^2)*x(6*i+1)+(-2*x(1)*x(2)-1)*x(6*i+2)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(6*i+2)=1*x(6*i+1);     
    dx(6*i+3)=(2*x(1))*x(6*i+1)+(2*x(2))*x(6*i+2)+2*u;      
    
    
    
    dx(6*i+4)=(1-x(5)^2)*x(6*i+4)+(-2*x(4)*x(5)-1)*x(6*i+5)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(6*i+5)=P_UBD(2)*x(6*i+4);     
    dx(6*i+6)=(2*x(4))*x(6*i+4)+(2*x(5))*x(6*i+5)+2*u;     
    else
        
    dx(6*i+1)=(1-x(2)^2)*x(6*i+1)+(-2*x(1)*x(2)-1)*x(6*i+2);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(6*i+2)=1*x(6*i+1);     
    dx(6*i+3)=(2*x(1))*x(6*i+1)+(2*x(2))*x(6*i+2);      
    
    
    
    dx(6*i+4)=(1-x(5)^2)*x(6*i+4)+(-2*x(4)*x(5)-1)*x(6*i+5);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(6*i+5)=P_UBD(2)*x(6*i+4);     
    dx(6*i+6)=(2*x(4))*x(6*i+4)+(2*x(5))*x(6*i+5);      
        
        
%     dx(3*i+1)=(1-x(2)^2)*x(3*i+1)+(-2*x(1)*x(2)-1)*x(3*i+2);    % df/dx+df/duj(j=1,2,3,4,i-1,i+1,7,8,9,10) 
%     dx(3*i+2)=1*x(3*i+2);     
%     dx(3*i+3)=(2*x(1))*x(3*i+1)+(2*x(2))*x(3*i+2);      
    end
   
   end
    case 3
              for m=1:3
           dx(3*m-1) = P_UBD(m)*x(3*m-2); 
        end
dx(1)=(1-x(2)^2)*x(1)-x(2)+u; %system state equs                                        
%dx(2) = x(1); 
dx(3)= x(1)^2+x(2)^2+u^2;




dx(4)=(1-x(5)^2)*x(4)-x(5)+u; %system state equs                                        
%dx(5) = 0.7*x(4); 
dx(6)= x(4)^2+x(5)^2+u^2; 
  


dx(7)=(1-x(8)^2)*x(7)-x(8)+u; %system state equs                                        
%dx(8) = *x(4); 
dx(9)= x(4)^2+x(5)^2+u^2; 


for i=1:N
    if i==pfs  %p��pathconstraints�е�PFS��Ҳ����ÿһ�ηֶ�i=1��N
    dx(9*i+1)=(1-x(2)^2)*x(9*i+1)+(-2*x(1)*x(2)-1)*x(9*i+2)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+2)=1*x(9*i+1);     
    dx(9*i+3)=(2*x(1))*x(9*i+1)+(2*x(2))*x(9*i+2)+2*u;      
    
    
    
    dx(9*i+4)=(1-x(5)^2)*x(9*i+4)+(-2*x(4)*x(5)-1)*x(9*i+5)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+5)=P_UBD(2)*x(9*i+4);     
    dx(9*i+6)=(2*x(4))*x(9*i+4)+(2*x(5))*x(9*i+5)+2*u;     
    
    
    dx(9*i+7)=(1-x(8)^2)*x(9*i+7)+(-2*x(7)*x(8)-1)*x(9*i+8)+1;     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+8)=P_UBD(3)*x(9*i+7);     
    dx(9*i+9)=(2*x(7))*x(9*i+7)+(2*x(8))*x(9*i+8)+2*u;    
    else
    dx(9*i+1)=(1-x(2)^2)*x(9*i+1)+(-2*x(1)*x(2)-1)*x(9*i+2);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+2)=1*x(9*i+1);     
    dx(9*i+3)=(2*x(1))*x(9*i+1)+(2*x(2))*x(9*i+2);      
    
    
    
    dx(9*i+4)=(1-x(5)^2)*x(9*i+4)+(-2*x(4)*x(5)-1)*x(9*i+5);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+5)=P_UBD(2)*x(9*i+4);     
    dx(9*i+6)=(2*x(4))*x(9*i+4)+(2*x(5))*x(9*i+5);     
    
    
    dx(9*i+7)=(1-x(8)^2)*x(9*i+7)+(-2*x(7)*x(8)-1)*x(9*i+8);     % df/dx+df/dui(i=1,2,3,4,5,6,7,8,9,10)
    dx(9*i+8)=P_UBD(3)*x(9*i+7);     
    dx(9*i+9)=(2*x(7))*x(9*i+7)+(2*x(8))*x(9*i+8);    
        
        
        
        
    end
   
   end



end
end

       
% for i=1:N
%     if i==pfs  
%         %%  ������
% 
% for h=1:3*b
% if mod(3*b*i+h, 3)==1 %x1 
%     a2= 3*floor(h/3)+2;
%     a1= 3*floor(h/3)+1;
%     dx(3*b*i+h)=(1-x(a2)^2)*x(3*b*i+h)+(-2*x(a1)*x(a2)-1)*x(3*b*i+h+1)+1;
% elseif mod(3*b*i+h, 3)==2 %x2
%     if mod(h, 3)==0
%         l=h/3;
%     else
%      l= floor(h/3)+1;
%     end
%      dx(3*b*i+h)=P_0(l)* dx(3*b*i+h);   
% else %x3
%     a2= 3*floor(h/3)-1;
%     a1= 3*floor(h/3)-2;
%     dx(3*b*i+h)=(2*x(a1))*x(3*b*i+h-2)+(2*x(a2))*x(3*b*i+h-1)+2*u;
% end
% end
%     else
%         
%   for h=1:3*b
% if mod(3*b*i+h, 3)==1 %x1
%     a2= 3*floor(h/3)+2;
%     a1= 3*floor(h/3)+1;
%     dx(3*b*i+h)=(1-x(a2)^2)*x(3*b*i+h)+(-2*x(a1)*x(a2)-1)*x(3*b*i+h+1);
% elseif mod(3*b*i+h, 3)==2 %x2
%     if mod(h, 3)==0
%         l=h/3;
%     else
%      l= floor(h/3)+1;
%     end
%      dx(3*b*i+h)=P_0(l)* dx(3*b*i+h);   
% else %x3
%     a2= 3*floor(h/3)-1;
%     a1= 3*floor(h/3)-2;
%     dx(3*b*i+h)=(2*x(a1))*x(3*b*i+h-2)+(2*x(a2))*x(3*b*i+h-1);
% end
% end      
%     end     
% end
