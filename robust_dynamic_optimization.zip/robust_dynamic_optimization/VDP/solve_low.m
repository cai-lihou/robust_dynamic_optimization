%% ���͹�͹�
function [decvar, fmin, inf_flag,output, LAMBDA,cost_grad] = solve_low(u,Current_Node)
options = optimset('GradConstr','on','Algorithm','sqp','MaxFunEvals',10000,'Display','iter','PlotFcns',{@optimplotfirstorderopt,@optimplotfval,@optimplotfunccount,@optimplotx...
    });
Var_bound = Current_Node;
%[Alpha1] = Alpha_cal(Var_bound(:,1),Var_bound(:,end),u);
intial_p = (0.5*Var_bound(:,1)+0.5*Var_bound(:,end))*ones(1,1);%1��1��Ҫ�޸�
 [X, FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD] = fmincon(@(p)costfunction_low(u,Current_Node,p),...
     intial_p,[],[],[],[],Var_bound(:,1),Var_bound(:,end),[],options);
decvar=X;       
fmin=FVAL;        
inf_flag=EXITFLAG; 
output=OUTPUT;    
cost_grad=GRAD;                    
end
