function [gmax, tmax] = LLP(u,p) 
global R  %same as defined in main.m
options = odeset('Refine', R);   %output more points between two
                                 % successive two computed steps
global T N x0      %same as defined in main.m
%y0=[9 0];
y0=x0;       %pass the initial condition of states

[I_path0,P_Gc0]=definepathcons(y0,u); %initial value of g
Gmax=I_path0;
Tmax=0;          %initial time of target
for i = 1:N  
[t,x]=ode45(@(t,x)defineode(t,x,u(i)),[(i-1)*T/(N), i*T/(N)],y0,options);
y0=x(end,:);     %connect the states
K=numel(t);      %during each time period, compute time points
g = zeros(K,1);  %create a vetor to store g
   for k=1:K
     [I_path,P_Gc] = definepathcons(x(k,:),u(i)); %compute g
     g(k,1) = I_path;
   end

figure(5)
hold on
plot(t,g(:,1),'b');         %plot g wrt t for the ith time subinterval
plot(t,x(:,1)-x(:,1),'m--'); %plot a horizen line at g=0

%K=numel(t);

for j=1:K
    
     if g(j)>Gmax         %get the maximumal value of g
        Gmax=g(j);
        Tmax=t(j);
     end
end

end


gmax = Gmax;  %return the values to main.m
tmax = Tmax;
gmax

p; %iteration numbers
c=num2str(p);  %transfer a number to a string
c=[' ',c];   
if gmax > 0
plot(Tmax, Gmax, 'rp','MarkerFaceColor','r','markersize',8); %plot maximumizer
text(Tmax, Gmax,c);  %plot the iteration numbers
else
plot(Tmax, Gmax, 'bp','MarkerFaceColor','b','markersize',8); %plot maximumizer
text(Tmax, Gmax,c);  %plot the iteration numbers
end
end



                 
