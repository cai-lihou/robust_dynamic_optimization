function dx=ode_events(t,x,p,u)
global tstart x0_events
if -((1-x0_events(2)^2)*x0_events(1)-x0_events(2)+u)<=0
    %its derivative of path constraint g at switching time is negative, i.e., g_dot at switching time
    q=0;
else 
    q=1;
end
 q;
 p;
gmax_dot=p*q*(-((1-x(2)^2)*x(1)-x(2)+u));%only if p=q=1; gmax_dot=g_dot, otherwise gmax_dot=0
%%%%%%�����е�٤��������
% dx=[u; 1; -u; gmax_dot]; 
dx=[(1-x(2)^2)*x(1)-x(2)+u; x(1); x(1)^2+x(2)^2+u^2-u;-((1-x(2)^2)*x(1)-x(2)+u); gmax_dot]; 

