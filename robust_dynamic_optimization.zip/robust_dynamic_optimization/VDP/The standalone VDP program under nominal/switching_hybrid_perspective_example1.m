function [Gmax, Tmax] = switching_hybrid_perspective_example1
clear all
global tstart x0
tstart = 0; %initial time
tfinal = 20;%final time
x0 = [5.1 6.7 -53.99 -53.99]; %initial values for x0, g_dot(t_0) and gmax_dot(t_0)
Y0=x0;
Gmax=Y0(1,4);
Tmax=0;

p=1; 
R = 4; %degree of refinement
options = odeset('Events',@events,'Refine', R,'RelTol',1e-5); %set events option
tout = tstart; %assigning values for tout (time variable in ODE45)
xout = x0;  % assigning values for xout (state variable ODE45)
teout = []; %teout is the column vector of time at which events occur
xeout = [];  %xeout is the corresponding solution at the events time
ieout = [];  %ieout specify which event occurs

for i = 1:2000  %assume events occurred are less than 20
    [t,x,te,xe,ie] = ode45(@fj,[tstart tfinal],x0,options,p); %solve ode45 with events option
    nt = length(t); %numbers of time between two consicutive events
    tout = [tout; t(2:nt)];  %time points
    xout = [xout; x(2:nt,:)]; %states
    teout = [teout; te];    
    xeout = [xeout; xe];
    ieout = [ieout; ie]; 

    if t(nt)>=tfinal %exceeds the final time
        i
        break
    end
                        
        if (xout(end,4)<=xout(end,3)) %if gmax <= g at switching time
            p=1; %
        else     %gmax>g
            p=0;
        end
  

    x0(1) = x(nt,1); %consistent initiailization
    x0(2) = x(nt,2); 
    x0(3) = x(nt,3);
    x0(4) = x(nt,4);
    %options = odeset(options,'InitialStep',t(nt)-t(nt-R),...
    %    'MaxStep',t(nt)-t(1));
    tstart = t(nt); %continue integration
end
figure
plot(tout, xout(:,1),'m', tout, xout(:,2),'g',tout, xout(:,3),'r',tout,xout(:,4),'bo')

xout;
tout;
xeout;
teout;
ieout;

 NT1=numel(tout)

for j=1:NT1
    if xout(j,4)>Gmax
        Gmax=xout(j,4);
        Tmax=tout(j);
    end
end


Gmax
Tmax
%set(gca,'xlim',[-3.5 0.5],'ylim',[-3.5 0.5]);
% hold on
% ezplot('y-2*x')
% hold on
% ezplot('y+10*x')
% -------------------------------------------------------------------------
function dx=fj(t,x,p)
global tstart x0
%-2*x0(1)*(cos(x0(2))+sin(tstart))
if -2*x0(1)*(cos(x0(2))+sin(tstart))<=0 %its derivative at switching time is negative, i.e., g_dot at switching time
    x0
    q=0;
else 
    q=1;
end
 q
 p
gmax_dot=p*q*(-2*x(1)*(cos(x(2))+sin(t)));%only if p=q=1; gmax_dot=g_dot, otherwise gmax_dot=0
x
dx=[-(cos(x(2))+sin(t)); -(sin(x(1))-cos(t)); -2*x(1)*(cos(x(2))+sin(t)); gmax_dot]; 
% -------------------------------------------------------------------------
function [value,isterminal,direction] = events(t,x,flag,b) %events function

H=-2*x(1)*(cos(x(2))+sin(t)); %derivative of path constraint g    
value = [x(4)-x(3); H]; %values of event functions
isterminal = [1; 1];    %stop itegration when crossing zeros
direction = [0; 0];    %both side crossing


