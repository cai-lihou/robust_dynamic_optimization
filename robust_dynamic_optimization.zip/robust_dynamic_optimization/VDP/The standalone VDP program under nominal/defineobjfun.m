function y = defineobjfun(x)   %Ŀ�꺯��Ϊ: miny3

%y = -x(end,2);  %define cost function
y = x(end,3);  %define cost function, which is the end element of the first column

end