%This algorithm is designed to locate an epsilon_approximated KKT point for  path-constrained
%dynamic programming (PCDP) with the SIP method via restriction of the
%right hand side proposed by Prof Alexander Mitsos published in Optimization

%here we only consider cost function is in a form of mayer formulation,i.e.,
%no integral part in the cost function. If a dynamic program has a
%Larangrian part, we can differentiate this Larangrian part wrt time, i.e.,
%x_(n+1)= F with intial condition x_(n+1)(t_0)=0. That is, this Larangrian
%part can be considered as a function of x_(n+1)(t_f).

%To use this code, you have to define objective function value in
%defineobjfun.m, inequality constraint in definepathcons.m, and ODE
%dynamics in defineode.m, and set intial value of states of ODE in main.m 


clear all %clear exiting data
clc  %clear screen
H = cputime;
global T N x0 %define the global variables where T is total time considered,and N 
                 %is the number of decision variables %x0 is initial value of sates,
                 %u0 is initial value of control
global lb ub u0 newu0  p %lower and upper bounds of control

global PFS       %PFS stands for parameter for sentivity equations




%% By adjusting the values of r and epsilon_g0, the variation in iteration numbers can be clearly observed.

 r = 2;          %a parameter to control how quickly \epislon is decreased
 epislon_g0 = 0.5;    %initial value of restriction parameter
 p=0;               %p is number of iterations
 N=10;           %The setting \(N=10\) is adopted here only for a quick verification of iteration variation, while the formal value adopted in the revised manuscript is \(N=50\).
%%


 u0 = 0.5;      %initialized the u0
 T=5;           %total time

 Init_val_sensi_equ = zeros(1, 3*N); %3 is the dimension of system, need to intialize the senstivity equs
 x0=[0 1 0 Init_val_sensi_equ]; 
 lb = -0.3;  %lower bounds of the decsion variables
 ub = 1;     %upper bounds of the decsion variables
 


 epsilon_act=1e-3;  %active tolerance
 epsilon_sat=1e-3;  %stationary tolerance,i.e, KKT error

 
 T0=5;  
%  T1=0.5; 
 T_UBD = [5];  %finite set of parameter variable of T_UBD

 epislon_g = epislon_g0;  %restriction parameter
  
[decvar, fmin, flag_inf, output,lambda,cost_grad] = upperbounding(T_UBD, epislon_g); %solve the UBD  
%locally which returns a minimizer (deccar), the corresponding optimal
%solution value, and flag reflecting feasibility of the UBD, multipliers
%and cost gradient

    c=-1; %define a slack variable for flow control
while c<=0    %enter the loop
      c=-1;   %start
      
 %%     
   if flag_inf == -2 %if the UBD is infeasible
      epislon_g = epislon_g/r; % decrease the restriction parameter to make 
                               % the UBD feasible 
      c=-5;                    %c=-5 means to solve the UBD with the updated 
                               % restriction parameter (see the bottom of the while loop)
   end
  
%%
   if c==-1              %the UBD is feasible 
      u_bar = decvar;  %set u_bar equal to the returned minimizer point
      p=p+1              % count the valid iterations
%       [gmax, tmax] = LLP(u_bar,p);%solve the LLP globally which returns
%                                   %the maximum objective solution value and
%                                   %the first maximizer (if more than one)
     [gmax, tmax] = LLP_events(u_bar,p)
      if gmax <= 0    %PCDP feasible 
         
         cost_gradient_PCDP = cost_grad; % cost gradient of PCDP from UBD
         multi_PCDP = lambda.ineqnonlin; % Multilplers of PCDP from UBD
         [d, ceq, Gc, Gceq] = pathconstraints(decvar,T_UBD,epislon_g); %d is a set of nonlinear constraints at all elements in T_UBD
          %ceq is nonlienar equality, Gc is inequality gradients of d wrt decision variables, Gceq is equality gradients
         h = numel(d); %calculate number of constraints
         d1=[d(1:h-2*N)-epislon_g d(h-2*N+1:h)]; % need to subtract epislon_g from d(1:h-2) but bounds are ok, since d=g+\epislon_g
         m =0; %intermidate variable
         for j=1:h
             if multi_PCDP(j)*d1(j)<-multi_PCDP(j)*epsilon_act  
             %if multi_PCDP(j)*d(j)<-multi_PCDP(j)*epsilon_act 
                 %complementary slackness does not hold, i.e., \lamba*g
                 %<-\lamba*\epsilon_act
                 epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
                 c=-5; %solve the UBD with updated epislon_g
             else
                 % complementary slackness holds
                 m=m+1; %to see how many inequalities of compementary slackness condition hold, if m==h, meaning compementary slackness holds
             end
         end
 
         if ((m==h)&&(norm(cost_gradient_PCDP+Gc*multi_PCDP)<=epsilon_sat))==1  % %theoretically no need to verify stationary equation,but practically need
             u_local=u_bar; %obtained local minimizer and local o
             f_local=fmin;
             c=3;%%break
         else
             epislon_g = epislon_g/r;  % feasible but not KKT, then reduce epislon_g
             c=-5; 
         end
            
     end
        
       
     if gmax > 0         %UBD is feasible but u_bar is infeasible to PCDP
           T_UBD = [T_UBD tmax]; %populate the T_UBD to exclude u_bar
           c=-4;              %c=-5 means to solve the UBD with the populated T_UBD  
           T_UBD
     end 
   
   end 

    %%
    if (c==-5 || c==-4)==1   %for reduce restriction parameter or populted T_UBD
        
        [decvar, fmin, flag_inf, output,lambda,cost_grad] = upperbounding(T_UBD, epislon_g); 
        epislon_g
    
              %solving UBD with either populated T_UBD or reduced epislon_g 
    end
end %end of flow control for feasibility of UBD
   


f_local   %displace the resulting local optimal solution value
u_local   %displace the resulting local minimizer

TIME = cputime-H  %cup time
% gmax              %output final gmax
% p
% epislon_g
% T_UBD



                