clear; clc; close all;

%% ���� (ֻ�����)
global T N x0 n_states n_params U_SEG U_NORM
T       = 40;
N       = 20;                    
x0      = [1, 0.2, 0.001, 250];
n_states= 4;
n_params= 2;                    

% ===================== ��ȡ³������ + ��ƿ��� =====================
load('all_results_my.mat');     
U_SEG = u_local;        % ³������
U_NORM = u_norm;        % ��ƿ���

S0_L = 360;    S0_U = 440;
Yx_L = 0.43;    Yx_U = 0.51;
Initial_rgn = [S0_L,S0_U; Yx_L,Yx_U];

Node = [];
Node{1} = Initial_rgn;

Width0 = Initial_rgn(:,2)-Initial_rgn(:,1);
Lowerbound_Nodes = [];
LB = -inf;
UB = inf;
tol = 0.1;
iter = 0;

%% ���Ź켣�洢����
global best_traj_t best_traj_x2 best_mv best_t_max
best_traj_t = [];
best_traj_x2 = [];
best_mv = 0;
best_t_max = 0;

%% ��ʼ���½�
[opt, fU, ef] = solver_local(Node{1});
if ef>=0
    UB = fU;
    best = opt;
end

[fL,ef] = solver_relaxation(Node{1});
LB = fL;
Lowerbound_Nodes = [Lowerbound_Nodes, fL];

%% ��ѭ��
while 1
    if isempty(Node)
        break;
    end
    if UB - LB <= tol
        disp('�������');
        break;
    end
    
    [~,cid] = min(Lowerbound_Nodes);
    cur = Node{cid};
    Node(cid)=[];
    Lowerbound_Nodes(cid)=[];
    
    w = cur(:,2)-cur(:,1);
    [~,d] = max(w./Width0);
    s = zeros(2,1);
    s(d)=w(d)/2;
    n1 = cur;
    n1(:,2)=n1(:,2)-s;
    n2 = cur;
    n2(:,1)=n2(:,1)+s;
    
    vals = [];
    sols=[];
    for i=1:2
        if i==1
            [o,f,e]=solver_local(n1);
        else
            [o,f,e]=solver_local(n2);
        end
        if e>=0
            vals=[vals,f];
            sols=[sols,o];
        end
    end
    
    if ~isempty(vals)
        [cm,id]=max(vals);
        if cm < UB
            UB = cm;
            best = sols(:,id);
        end
    end
    
    keep = true(size(Node));
    for i=1:numel(Node)
        if Lowerbound_Nodes(i)>UB
            keep(i)=false;
        end
    end
    Node = Node(keep);
    Lowerbound_Nodes = Lowerbound_Nodes(keep);
    
    lns = [-inf,-inf];
    for i=1:2
        if i==1
            [f,e]=solver_relaxation(n1);
        else
            [f,e]=solver_relaxation(n2);
        end
        if e>=0
            lns(i)=f;
        end
    end
    
    for i=1:2
        if lns(i)<LB
            lns(i)=LB;
        end
        if lns(i)<=UB
            if i==1
                Node{end+1} = n1;
            else
                Node{end+1} = n2;
            end
            Lowerbound_Nodes = [Lowerbound_Nodes,lns(i)];
        end
    end
    
    LB = min(Lowerbound_Nodes);
    iter=iter+1;
end

% ===================== ���ƶԱ� =====================
if ~isnan(best(1))
    plot_best_trajectory(best(1), best(2));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �·�������ȫ����
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fval,ef] = solver_relaxation(Node)
global T N x0
VL = Node(:,1);
VU = Node(:,2);
[A1,A2] = Alpha_cal(VL,VU);
x0u = [mean([VL(1),VU(1)]), mean([VL(2),VU(2)])];

opts = optimoptions(@fmincon,'SpecifyObjectiveGradient',true,...
    'Algorithm','sqp','Display','none');

[~,fval,ef] = fmincon(@(u)objfunction_relaxation(u,VL,VU,A1,A2),x0u,[],[],[],[],VL,VU,[],opts);
end

function [opt,fval,ef] = solver_local(Node)
global T N x0
VL = Node(:,1);
VU = Node(:,2);
x0u = [mean([VL(1),VU(1)]), mean([VL(2),VU(2)])];

opts = optimoptions(@fmincon,'SpecifyObjectiveGradient',true,...
    'Algorithm','sqp','Display','none');

[opt,fval,ef] = fmincon(@objfunction_local,x0u,[],[],[],[],VL,VU,[],opts);
end

function dx = ode_with_xq_new(t,X,S0,Yx,u)
global n_states n_params
x = X(1:n_states);
x1=x(1);x2=x(2);x3=x(3);x4=x(4);

dx = zeros(n_states + n_states*n_params, 1);
dx(1:4) = ode_define_new(t,x,S0,Yx,u);

s11 = X(5);  s21 = X(6);  s31 = X(7);  s41 = X(8);
s12 = X(9);  s22 = X(10); s32 = X(11);s42 = X(12);

df1ds0 = 0;
df2ds0 = u/x4;
df3ds0 = 0;
df4ds0 = 0;

dx(5) = (-u/x4)*s11 + df1ds0;
dx(6) = (-u/x4)*s21 + df2ds0;
dx(7) = (-u/x4)*s31 + df3ds0;
dx(8) = 0*s41 + df4ds0;

df1dyx = 0;
df2dyx = 0.11*x1*x2/((0.006*x1+x2)*Yx^2);
df3dyx = 0;
df4dyx = 0;

dx(9)  = (-u/x4)*s12 + df1dyx;
dx(10) = (-u/x4)*s22 + df2dyx;
dx(11) = (-u/x4)*s32 + df3dyx;
dx(12) = 0*s42 + df4dyx;
end

function dx = ode_define_new(t,x,S0,Yx,u)
x1 = x(1); x2 = x(2); x3 = x(3); x4 = x(4);
dx = zeros(4,1);

dx(1) = 0.11*x1*x2/(0.006*x1+x2) - u*x1/x4;

dx(2) = -0.11*x1*x2/((0.006*x1+x2)*Yx) ...
        -0.029*x1 ...
        -0.004*x1*x2/(1.2*(x2+0.0001+x2^2/0.1)) ...
        + u*(S0-x2)/x4;

dx(3) = 0.004*x1*x2/(x2+0.0001+x2^2/0.1) -0.01*x3 -u*x3/x4;
dx(4) = u;
end

function [f,g] = objfunction_relaxation(uvec,VL,VU,A1,A2)
global T N x0 U_SEG
S0 = uvec(1); Yx = uvec(2);

t_seg = linspace(0,T,N+1);
x_cur = x0;
X_all = [];

for i=1:N
    ui = U_SEG(i);
    [~,X] = ode45(@(tt,xx)ode_define_new(tt,xx,S0,Yx,ui),[t_seg(i),t_seg(i+1)],x_cur);
    x_cur = X(end,:);
    X_all = [X_all;X];
end
val = X_all(:,2)-0.5;
[mv,~]=max(val);

[f0,g0] = objfunction_local(uvec);
f = f0 + A1*(VL(1)-S0)*(VU(1)-S0) + A2*(VL(2)-Yx)*(VU(2)-Yx);
g = g0 + [A1*(VL(1)+VU(1)-2*S0); A2*(VL(2)+VU(2)-2*Yx)];
end

function [f, g] = objfunction_local(uvec)
global T N x0 n_states n_params U_SEG best_traj_t best_traj_x2 best_mv best_t_max
S0 = uvec(1);
Yx = uvec(2);

t_seg = linspace(0,T,N+1);
x_cur = x0;
X_all = [];
t_all = [];

for i=1:N
    t_span = [t_seg(i), t_seg(i+1)];
    ui = U_SEG(i);
    [t,X] = ode45(@(tt,xx)ode_define_new(tt,xx,S0,Yx,ui),t_span,x_cur);
    x_cur = X(end,:);
    X_all = [X_all; X];
    t_all = [t_all; t];
end

val = X_all(:,2) - 0.5;
[mv, idx] = max(val);
t_max = t_all(idx);

X0_aug = [x0'; zeros(8,1)];
x_cur_aug = X0_aug;

for i=1:N
    t_span = [t_seg(i), t_seg(i+1)];
    ui = U_SEG(i);
    [tt,XX] = ode45(@(tt,xx)ode_with_xq_new(tt,xx,S0,Yx,ui), t_span, x_cur_aug);
    x_cur_aug = XX(end,:)';
end

dx2ds0 = x_cur_aug(6);
dx2dyx = x_cur_aug(10);

f = -mv;
g = [-dx2ds0; -dx2dyx];
end

function [A1,A2] = Alpha_cal(VL,VU)
A1 = 1e-3;
A2 = 1e-3;
end
% ===================== ���ֿ���ͼ��³�� / ��� ��һ�š� =====================
function plot_best_trajectory(S0_opt, Yx_opt)
global T N x0 U_SEG U_NORM

%% -------- 1. ³������ ������ͼ --------
[t_rob, x2_rob] = sim_u(U_SEG, S0_opt, Yx_opt);
obj_rob = x2_rob - 0.5;
[max_rob, idx_rob] = max(obj_rob);
t_rob_peak = t_rob(idx_rob);

figure('Color','w','Position',[100,100,800,400])
hold on; grid on; box on;
plot(t_rob, obj_rob, 'b-', 'LineWidth', 2.5, 'DisplayName','u_{robust}');
yline(0, 'r--', 'LineWidth', 2, 'DisplayName','x_2=0.5 Լ��');
scatter(t_rob_peak, max_rob, 180, 'r', 'p', 'filled');
xlabel('ʱ�� t');
ylabel('x_2 - 0.5');
title(sprintf('³������ | ����� S0=%.2f, Yx=%.2f\n���Լ��Υ�� = %.4f',...
    S0_opt, Yx_opt, max_rob));
legend;
ylim([min(obj_rob)-0.02, max(obj_rob)+0.02]);

%% -------- 2. ��ƿ��� ������ͼ --------
[t_nom, x2_nom] = sim_u(U_NORM, S0_opt, Yx_opt);
obj_nom = x2_nom - 0.5;
[max_nom, idx_nom] = max(obj_nom);
t_nom_peak = t_nom(idx_nom);

figure('Color','w','Position',[100,500,800,400])
hold on; grid on; box on;
plot(t_nom, obj_nom, 'Color',[0.9,0.4,0.0], 'LineWidth',2.5,'DisplayName','u_{norm}');
yline(0, 'r--', 'LineWidth', 2, 'DisplayName','x_2=0.5 Լ��');
scatter(t_nom_peak, max_nom, 180, [0.9,0.4,0.0], 'p', 'filled');
xlabel('ʱ�� t');
ylabel('x_2 - 0.5');
title(sprintf('��ƿ��� | ����� S0=%.2f, Yx=%.2f\n���Լ��Υ�� = %.4f',...
    S0_opt, Yx_opt, max_nom));
legend;
ylim([min(obj_nom)-0.02, max(obj_nom)+0.02]);

fprintf('--- ���Լ��Υ�� ---\n');
fprintf('³�� u_robust: %.4f\n', max_rob);
fprintf('��� u_norm  : %.4f\n', max_nom);
end

% ���溯��
function [t_out, x2_out] = sim_u(u_seg, S0, Yx)
global T N x0
t_seg = linspace(0, T, N+1);
x_cur = x0;
t_all = [];
x2_all = [];

for i = 1:N
    ui = u_seg(i);
    [t, X] = ode45(@(tt,xx) ode_define_new(tt,xx,S0,Yx,ui), [t_seg(i), t_seg(i+1)], x_cur);
    t_all = [t_all; t];
    x2_all = [x2_all; X(:,2)];
    x_cur = X(end,:);
end

t_out = t_all;
x2_out = x2_all;
end