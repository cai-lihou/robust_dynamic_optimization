clear all
clc
close all

%% ===================== �Զ��������³������ =====================
fprintf('���ڼ��� all_results_my.mat ...\n');
load('all_results_my.mat');
u_robust = u_local;   % ��ȡ³�����ſ���
u_norm   = u_norm;    % ��ƿ���
N = length(u_robust);
T = 40;
x0 = [1, 0.2, 0.001, 250];

fprintf('? ���سɹ������ƶ��� N = %d\n\n', N);

%% ��ȷ��������Χ
S0_L = 360;    S0_U = 440;
Yx_L = 0.43;   Yx_U = 0.51;
S0_nom = 400;
Yx_nom = 0.47;

% ===================== 1. S0 ���ȱ仯 =====================
fprintf('1. S0 ���ȱ仯 100 ��...\n');
figure; hold on; grid on; box on;
for i = 1:100
    S0 = S0_L + (S0_U - S0_L)*(i-1)/99;
    Yx = Yx_nom;
    [t, x2] = simulate_full(u_robust, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[0.2, 0.4, 1, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
    [t, x2] = simulate_full(u_norm, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[1, 0.8, 0.2, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
end
plot(NaN,NaN,'Color',[0.2,0.4,1],'LineWidth',2.5,'DisplayName','Robust control');
plot(NaN,NaN,'Color',[1,0.8,0.2],'LineWidth',2.5,'DisplayName','Nominal control');

yline(0.5,'r--','LineWidth',2.0,'DisplayName','x_2=0.5');
xlabel('t'); ylabel('x_2(t)');
title('S0 ���ȱ仯 | Y_x=0.47');
xlim([0,T]);
legend('Location','best');

% ===================== 2. Yx ���ȱ仯 =====================
fprintf('2. Yx ���ȱ仯 100 ��...\n');
figure; hold on; grid on; box on;
for i = 1:100
    Yx = Yx_L + (Yx_U - Yx_L)*(i-1)/99;
    S0 = S0_nom;
    [t, x2] = simulate_full(u_robust, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[0.2, 0.4, 1, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
    [t, x2] = simulate_full(u_norm, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[1, 0.8, 0.2, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
end
plot(NaN,NaN,'Color',[0.2,0.4,1],'LineWidth',2.5,'DisplayName','Robust control');
plot(NaN,NaN,'Color',[1,0.8,0.2],'LineWidth',2.5,'DisplayName','Nominal control');

yline(0.5,'r--','LineWidth',2.0,'DisplayName','x_2=0.5');
xlabel('t'); ylabel('x_2(t)');
title('Y_x ���ȱ仯 | S_0=400');
xlim([0,T]);
legend('Location','best');

% ===================== 3. ������� =====================
fprintf('3. ������� 100 ��...\n');
figure; hold on; grid on; box on;
for i = 1:100
    S0 = S0_L + (S0_U-S0_L)*rand;
    Yx = Yx_L + (Yx_U-Yx_L)*rand;
    [t, x2] = simulate_full(u_robust, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[0.2, 0.4, 1, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
    [t, x2] = simulate_full(u_norm, T, N, x0, S0, Yx);
    plot(t, x2, 'Color',[1, 0.8, 0.2, 0.4], 'LineWidth',0.8, 'HandleVisibility','off');  % ����
end
plot(NaN,NaN,'Color',[0.2,0.4,1],'LineWidth',2.5,'DisplayName','Robust control');
plot(NaN,NaN,'Color',[1,0.8,0.2],'LineWidth',2.5,'DisplayName','Nominal control');

yline(0.5,'r--','LineWidth',2.0,'DisplayName','x_2=0.5');
xlabel('t'); ylabel('x_2(t)');
title('S_0 & Y_x ����仯');
xlim([0,T]);
legend('Location','best');

fprintf('\n? ȫ��ͳһΪ����+������ɫ���ص���ڣ�\n');

%% =============================================================================
% 100% ƥ�������� OdeSnstv_VDPO ����
%% =============================================================================
function [t_out, x2_out] = simulate_full(u_seg, T, N, x0, S0, Yxs)
    t_seg  = linspace(0, T, N+1);
    x_cur  = x0;
    t_all  = [];
    x2_all = [];
    
    Kl=0.006;
    mu=0.11;
    theta=0.004;
    Yp=1.2;
    Ki=0.1;
    Mx=0.029;
    Kxp=0.01;
    Kp=0.0001;
    
    for i = 1:N
        ui = u_seg(i);
        odef = @(t,x) [
            mu*x(1)*x(2)/(Kl*x(1)+x(2)) - ui*x(1)/x(4);
            -mu*x(1)*x(2)/(Yxs*(Kl*x(1)+x(2))) - theta*x(1)*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki)) - Mx*x(1) + ui*(S0-x(2))/x(4);
            theta*x(1)*x(2)/(x(2)+Kp+x(2)^2/Ki) - Kxp*x(3) - ui*x(3)/x(4);
            ui
        ];
        [t, X] = ode45(odef, [t_seg(i), t_seg(i+1)], x_cur);
        
        t_all  = [t_all; t];
        x2_all = [x2_all; X(:,2)];
        x_cur  = X(end,:);
    end
    
    t_out  = t_all;
    x2_out = x2_all;
end