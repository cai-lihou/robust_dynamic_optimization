function [f_worst, g_worst] = objfunction_local_worst(uvec, ...
    T_worst, N_worst, x0_worst, n_states_worst, n_params_worst, U_SEG_worst)

S0 = uvec(1);
Yx = uvec(2);
t_seg = linspace(0, T_worst, N_worst+1);
x_cur = x0_worst;
X_all = [];

for i = 1:N_worst
    ui = U_SEG_worst(i);
    [t,X] = ode45(@(tt,xx) ode_define_new_worst(tt,xx,S0,Yx,ui), ...
        [t_seg(i), t_seg(i+1)], x_cur);
    x_cur = X(end,:);
    X_all = [X_all; X];
end

val = X_all(:,2) - 0.5;
[mv,~] = max(val);

X0_aug = [x0_worst'; zeros(8,1)];
x_aug = X0_aug;

for i = 1:N_worst
    ui = U_SEG_worst(i);
    [~,XX] = ode45(@(tt,xx) ode_with_xq_new_worst(tt,xx,S0,Yx,ui), ...
        [t_seg(i), t_seg(i+1)], x_aug);
    x_aug = XX(end,:)';
end

dx2ds0 = x_aug(6);
dx2dyx = x_aug(10);

f_worst = -mv;
g_worst = [-dx2ds0; -dx2dyx];
end