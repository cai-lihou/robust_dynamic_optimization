function [A1, A2] = Alpha_cal_worst()
A1 = 1e-3;
A2 = 1e-3;
end