function dx = ode_with_xq_new_worst(t, X, S0, Yx, u)
x = X(1:4);
x1 = x(1); x2 = x(2); x3 = x(3); x4 = x(4);

dx = zeros(12, 1);
dx(1:4) = ode_define_new_worst(t, x, S0, Yx, u);

s11 = X(5);  s21 = X(6);  s31 = X(7);  s41 = X(8);
s12 = X(9);  s22 = X(10); s32 = X(11); s42 = X(12);

df1ds0 = 0;
df2ds0 = u/x4;
df3ds0 = 0;
df4ds0 = 0;

dx(5)  = (-u/x4)*s11 + df1ds0;
dx(6)  = (-u/x4)*s21 + df2ds0;
dx(7)  = (-u/x4)*s31 + df3ds0;
dx(8)  = 0;

df1dyx = 0;
df2dyx = 0.11*x1*x2/((0.006*x1+x2)*Yx^2);
df3dyx = 0;
df4dyx = 0;

dx(9)  = (-u/x4)*s12 + df1dyx;
dx(10) = (-u/x4)*s22 + df2dyx;
dx(11) = (-u/x4)*s32 + df3dyx;
dx(12) = 0;
end