function [cieq, ceq, G_cieq, G_ceq] = pathconstraints(u,T_Dis,epislon_g)
%需要修改cieq P_Gc
global N T x0
CvpGrd = 0:T/N:T;
N_TD = numel(T_Dis);
NStat = numel(x0);

y0=x0;
y0=[y0,zeros(1,NStat*N)];
NStatAug = numel(y0);

x_TD = zeros(N_TD,NStatAug); % State variables at discretization points
cieq = zeros(1,N_TD); % creat a vector with M elements
G_cieq =zeros(N,N_TD);
OdeOption = odeset('RelTol',1e-9,'AbsTol',1e-9);

for i = 1:N % for each element of the control vector paremetrization
    [t,x]=ode45(@(t,x)OdeSnstv_VDPO(t,x,u(i),i,N),[CvpGrd(i), CvpGrd(i+1)],y0,OdeOption); %i stands for the ith decision variables, for sensitivity equ
    y0=x(end,:);  %connect the trajectory

    for j=1:N_TD 
        
        if ( (T_Dis(j)>=CvpGrd(i)) && ( (i==N) || (T_Dis(j)<CvpGrd(i+1))))==1%%找出T_UBD所在的区间
                
            x_TD(j,:) = interp1(t,x,T_Dis(j),'PCHIP'); %插值求得系统状态在T_UBD的值
            cieq(1,j) = x_TD(j,2) - 0.5 + epislon_g;%%路径约束在T_UBD的函数值  g(u,t)+εg≤0              

            G_cieq(:,j) = x_TD(j,NStat+2:NStat:NStat+NStat*N);

        end 
    end   
end 


G_ceq = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%求u(i)约束的导数，此时u（i）是不断变化的
%inequ = I;%path constraint 第一个为约束条件-x(1)-0.4
%number_cons = numel(I)

for i=1:N
    cieq = [cieq u(i)-10 0-u(i)];%%后20个是论文中的U的上下界的不等式约束
end  
  %satisfy the path constraint in UBD and bounded controls here only one decision varialbe 
            %since u is some constant to be designed. 
            %for multiple decision variables, need recode decision vector u, 
            %for time being, hard coded.
ceq = [];

grad_bounds = zeros(N,2*N);
for i=1:N   %compute gradients of bound inequaliteis
  grad_bounds(i,2*i-1)= grad_bounds(i,2*i-1)+1; %replace 0 with 1, i.e., [1 0 0 0...]'
  grad_bounds(i,2*i)= grad_bounds(i,2*i)-1;%repalce 0 with -1  i.e., [-1 0 0 0...]'
end
 %%   
G_cieq = [G_cieq grad_bounds]; %constraints gradients (path+bounds)%[不等式的梯度P,边界的梯度grad_bounds]边界的梯度是对u的导数，把u（i）当成变量，对u（i）求导
Gceq = [];

end


