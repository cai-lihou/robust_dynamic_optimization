function [best_worst, max_violation_worst,iter_worst] = LLP_PP(U_SEG_in)
T_worst = 40;
N_worst = 20;
x0_worst = [1, 0.2, 0.001, 250];
n_states_worst = 4;
n_params_worst = 2;
U_SEG_worst = U_SEG_in;

S0_L_worst = 360;
S0_U_worst = 440;
Yx_L_worst = 0.43;
Yx_U_worst = 0.51;
Initial_rgn_worst = [S0_L_worst, S0_U_worst;
                     Yx_L_worst, Yx_U_worst];

Node_worst = {Initial_rgn_worst};
Width0_worst = Initial_rgn_worst(:,2) - Initial_rgn_worst(:,1);
Lowerbound_Nodes_worst = [];
LB_worst = -inf;
UB_worst = inf;
tol_worst = 0.1;
iter_worst = 0;

[opt_worst, fU_worst, ef_worst] = solver_local_worst(Node_worst{1}, ...
    T_worst, N_worst, x0_worst, n_states_worst, n_params_worst, U_SEG_worst);
if ef_worst >= 0
    UB_worst = fU_worst;
    best_worst = opt_worst;
end

[fL_worst, ef_worst] = solver_relaxation_worst(Node_worst{1}, ...
    T_worst, N_worst, x0_worst, n_states_worst, n_params_worst, U_SEG_worst);
LB_worst = fL_worst;
Lowerbound_Nodes_worst = [Lowerbound_Nodes_worst, fL_worst];

while 1
    if isempty(Node_worst) || (UB_worst - LB_worst <= tol_worst)
        break;
    end

    [~, cid_worst] = min(Lowerbound_Nodes_worst);
    cur_worst = Node_worst{cid_worst};
    Node_worst(cid_worst) = [];
    Lowerbound_Nodes_worst(cid_worst) = [];

    w_worst = cur_worst(:,2) - cur_worst(:,1);
    [~, d_worst] = max(w_worst ./ Width0_worst);
    s_worst = zeros(2,1);
    s_worst(d_worst) = w_worst(d_worst)/2;

    n1_worst = cur_worst; n1_worst(:,2) = n1_worst(:,2) - s_worst;
    n2_worst = cur_worst; n2_worst(:,1) = n2_worst(:,1) + s_worst;

    vals_worst = []; sols_worst = [];
    for i = 1:2
        if i == 1
            [o_w,f_w,e_w] = solver_local_worst(n1_worst, ...
                T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst);
        else
            [o_w,f_w,e_w] = solver_local_worst(n2_worst, ...
                T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst);
        end
        if e_w >= 0
            vals_worst = [vals_worst, f_w];
            sols_worst = [sols_worst, o_w];
        end
    end

    if ~isempty(vals_worst)
        [cm_w, id_w] = max(vals_worst);
        if cm_w < UB_worst
            UB_worst = cm_w;
            best_worst = sols_worst(:, id_w);
        end
    end

    keep = true(size(Node_worst));
    for i = 1:numel(Node_worst)
        if Lowerbound_Nodes_worst(i) > UB_worst
            keep(i) = false;
        end
    end
    Node_worst = Node_worst(keep);
    Lowerbound_Nodes_worst = Lowerbound_Nodes_worst(keep);

    lns = [-inf, -inf];
    for i = 1:2
        if i == 1
            [f_w,e_w] = solver_relaxation_worst(n1_worst, ...
                T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst);
        else
            [f_w,e_w] = solver_relaxation_worst(n2_worst, ...
                T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst);
        end
        if e_w >= 0
            lns(i) = f_w;
        end
    end

    for i = 1:2
        if lns(i) < LB_worst
            lns(i) = LB_worst;
        end
        if lns(i) <= UB_worst
            if i == 1
                Node_worst{end+1} = n1_worst;
            else
                Node_worst{end+1} = n2_worst;
            end
            Lowerbound_Nodes_worst = [Lowerbound_Nodes_worst, lns(i)];
        end
    end

    LB_worst = min(Lowerbound_Nodes_worst);
    iter_worst = iter_worst + 1;
end

max_violation_worst = -UB_worst;
best_worst = [best_worst(2), best_worst(1)];
fprintf('� Yx = %.4f\n', best_worst(1));
fprintf('� S0 = %.4f\n', best_worst(2));
fprintf('�Լ��Υ�� max(x2-0.5) = %.6f\n', max_violation_worst);
end