function [objval,Gobj] = costfunction(u)
%不需修改 obj Gobj
global T N x0

CvpGrd = 0:T/N:T;

NStat = numel(x0);
y0=x0;%%状态初值
y0=[y0,zeros(1,NStat*N)];
OdeOption = odeset('RelTol',1e-9,'AbsTol',1e-9);
for i = 1:N
    [t,x]=ode45(@(t,x)OdeSnstv_VDPO(t,x,u(i),i,N),CvpGrd(i:i+1),y0,OdeOption);
    y0=x(end,:); %solve ode
end

objval = -x(end,3);

Gobj = -x(end,NStat+3:NStat:NStat*N+NStat)';


end

