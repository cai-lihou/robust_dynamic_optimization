function [u_robust, f_robust, total_iter_all, epsilon_g] = run_robust_optimization(wst_params)

n_wst = size(wst_params, 1);
Yxs_wst_array = wst_params(:, 1);
S0_wst_array  = wst_params(:, 2);

x0 = [1 0.2 0.001 250];
x0_all = x0;
for i = 1:n_wst
    x0_all = [x0_all, x0];
end

u0 = 1;
T = 40;
N = 20;
lb = zeros(1,N);
ub = 10*ones(1,N);
U_0 = u0*ones(1,N);
r = 4;
epsilon_act = 0.001;
epsilon_sat = 0.001;
epsilon_g0 = 0.001;
epsilon_g = epsilon_g0;
T_Dis = 0:1:40;

optim_opts = optimset('GradConstr','on',...
    'Algorithm','sqp',...
    'MaxFunEvals',10000,...
    'Display','iter',...  % ��ʾ³���Ż�����
    'TolFun',0.001);

total_iter_all = 0;

% ��һ�� fmincon
[u, fmin,inf_flag,~,lambda,cost_grad] = fmincon(...
    @(u) robust_cost_function(u, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array),...
    U_0,[],[],[],[],lb,ub,...
    @(u) robust_path_constraints(u,T_Dis,epsilon_g, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array),...
    optim_opts);
total_iter_all = total_iter_all + 1;

c = -1;
while c <= 0
    c = -1;

    if inf_flag == -2
        epsilon_g = epsilon_g / r;
        c = -5;
        total_iter_all = total_iter_all + 1;
    end

    if c == -1
        [gmax,tmax,~,~] = robust_llp_events(u, T, N, x0_all, Yxs_wst_array, S0_wst_array, n_wst);

        if gmax <= 0
            cost_gradient_PCDP = cost_grad;
            multi_PCDP = lambda.ineqnonlin;
            [d,~,Gc,~] = robust_path_constraints(u,T_Dis,epsilon_g, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array);
            h = numel(d);
            d1 = [d(1:h-2*N)-epsilon_g d(h-2*N+1:h)];
            m = 0;
            kkt_fail = false;

            num_pts = length(T_Dis);
            for j=1:num_pts
                idx1 = 2*(j-1)+1;
                idx2 = 2*(j-1)+2;
                val1 = multi_PCDP(idx1)*d1(idx1);
                val2 = multi_PCDP(idx2)*d1(idx2);
                if val1 < -epsilon_act || val2 < -epsilon_act
                    kkt_fail = true;
                    break;
                else
                    m = m+2;
                end
            end
            for j = 2*num_pts+1 : h
                if multi_PCDP(j)*d1(j) < -epsilon_act
                    kkt_fail = true;
                    break;
                else
                    m = m+1;
                end
            end

            stationarity_val = norm(cost_gradient_PCDP + Gc * multi_PCDP);

            if ~kkt_fail && m == h && stationarity_val <= epsilon_sat
                u_robust = u;
                f_robust = fmin;
                c = 3;
            else
                epsilon_g = epsilon_g / r;
                c = -5;
                total_iter_all = total_iter_all + 1;
            end
        else
            T_Dis = unique([T_Dis, tmax]);
            c = -4;
            total_iter_all = total_iter_all + 1;
        end
    end

    if c == -5 || c == -4
        Start_Point = u;
        [u, fmin,inf_flag,~,lambda,cost_grad] = fmincon(...
            @(u) robust_cost_function(u, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array),...
            Start_Point,[],[],[],[],lb,ub,...
            @(u) robust_path_constraints(u,T_Dis,epsilon_g, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array),...
            optim_opts);
        total_iter_all = total_iter_all + 1;
    end
end

end