% function dx = robust_ode_sensitivity(t,x,Dec,Index,N, Yxs_wst_array, S0_wst_array, n_wst)
% u = Dec;
% dim_sys = 4 + 4 * n_wst;
% dx = zeros(dim_sys + dim_sys*N, 1);
% 
% Kl=0.006; mu=0.11; Yxs_nom=0.47; theta=0.004; Yp=1.2; Ki=0.1;
% Mx=0.029; Kxp=0.01; Kp=0.0001; S0_nom=400;
% 
% x1n=x(1); x2n=x(2); x3n=x(3); x4n=x(4);
% dn=Kl*x1n+x2n;
% dx(1)=mu*x1n*x2n/dn-u*x1n/x4n;
% dx(2)=-mu*x1n*x2n/(Yxs_nom*dn)-theta*x1n*x2n/(Yp*(x2n+Kp+x2n^2/Ki))-Mx*x1n+u*(S0_nom-x2n)/x4n;
% dx(3)=theta*x1n*x2n/(x2n+Kp+x2n^2/Ki)-Kxp*x3n-u*x3n/x4n;
% dx(4)=u;
% 
% for k = 1:n_wst
%     off = 4 + (k-1)*4;
%     Yxs_wst = Yxs_wst_array(k);
%     S0_wst  = S0_wst_array(k);
%     x1w = x(off+1); x2w = x(off+2); x3w = x(off+3); x4w = x(off+4);
%     dw  = Kl*x1w + x2w;
%     dx(off+1) = mu*x1w*x2w/dw - u*x1w/x4w;
%     dx(off+2) = -mu*x1w*x2w/(Yxs_wst*dw) - theta*x1w*x2w/(Yp*(x2w+Kp+x2w^2/Ki)) - Mx*x1w + u*(S0_wst-x2w)/x4w;
%     dx(off+3) = theta*x1w*x2w/(x2w+Kp+x2w^2/Ki) - Kxp*x3w - u*x3w/x4w;
%     dx(off+4) = u;
% end
% 
% for i = 1:N
%     Idx0 = dim_sys + (i-1)*dim_sys;
%     if i == Index
%         DX11=mu*x2n^2/dn^2-u/x4n;
%         DX12=mu*Kl*x1n^2/dn^2;
%         DX14=u*x1n/x4n^2;
%         dx(Idx0+1) = DX11*x(Idx0+1) + DX12*x(Idx0+2) + DX14*x(Idx0+4)-x1n/x4n;
% 
%         DX21=-mu*x2n^2/(Yxs_nom*dn^2)-theta*x2n/(Yp*(x2n+Kp+x2n^2/Ki))-Mx;
%         DX22=-mu*Kl*x1n^2/(Yxs_nom*dn^2)-theta*x1n*(Kp-x2n^2/Ki)/(Yp*(x2n+Kp+x2n^2/Ki)^2)-u/x4n;
%         DX24=-u*(S0_nom-x2n)/x4n^2;
%         dx(Idx0+2) = DX21*x(Idx0+1) + DX22*x(Idx0+2) + DX24*x(Idx0+4)+(S0_nom-x2n)/x4n;
% 
%         DX31=theta*x2n/(x2n+Kp+x2n^2/Ki);
%         DX32=theta*x1n*(Kp-x2n^2/Ki)/(x2n+Kp+x2n^2/Ki)^2;
%         DX33=-Kxp-u/x4n;
%         DX34=u*x3n/x4n^2;
%         dx(Idx0+3) = DX31*x(Idx0+1) + DX32*x(Idx0+2) + DX33*x(Idx0+3) + DX34*x(Idx0+4)-x3n/x4n;
%         dx(Idx0+4) = 1;
% 
%         for k = 1:n_wst
%             off = 4 + (k-1)*4;
%             Yxs_wst = Yxs_wst_array(k);
%             S0_wst  = S0_wst_array(k);
%             x1w = x(off+1); x2w = x(off+2); x3w = x(off+3); x4w = x(off+4);
%             dw  = Kl*x1w + x2w;
% 
%             DX11w=mu*x2w^2/dw^2-u/x4w;
%             DX12w=mu*Kl*x1w^2/dw^2;
%             DX14w=u*x1w/x4w^2;
%             dx(Idx0+off+1) = DX11w*x(Idx0+off+1) + DX12w*x(Idx0+off+2) + DX14w*x(Idx0+off+4)-x1w/x4w;
% 
%             DX21w=-mu*x2w^2/(Yxs_wst*dw^2)-theta*x2w/(Yp*(x2w+Kp+x2w^2/Ki))-Mx;
%             DX22w=-mu*Kl*x1w^2/(Yxs_wst*dw^2)-theta*x1w*(Kp-x2w^2/Ki)/(Yp*(x2w+Kp+x2w^2/Ki)^2)-u/x4n;
%             DX24w=-u*(S0_wst-x2w)/x4w^2;
%             dx(Idx0+off+2) = DX21w*x(Idx0+off+1) + DX22w*x(Idx0+off+2) + DX24w*x(Idx0+off+4)+(S0_wst-x2w)/x4w;
% 
%             DX31w=theta*x2w/(x2w+Kp+x2w^2/Ki);
%             DX32w=theta*x1n*(Kp-x2w^2/Ki)/(x2w+Kp+x2w^2/Ki)^2;
%             DX33w=-Kxp-u/x4w;
%             DX34w=u*x3w/x4w^2;
%             dx(Idx0+off+3) = DX31w*x(Idx0+off+1) + DX32w*x(Idx0+off+2) + DX33w*x(Idx0+off+3) + DX34w*x(Idx0+off+4)-x3w/x4w;
%             dx(Idx0+off+4) = 1;
%         end
%     else
%         dx(Idx0+1 : Idx0+dim_sys) = 0;
%     end
% end
% end
% 


%%



function dx = robust_ode_sensitivity(t,x,Dec,Index,N, Yxs_wst_array, S0_wst_array, n_wst)
u = Dec;
dim_nom = 4;
dim_wst = 4 * n_wst;
dim_sys = dim_nom + dim_wst;
dx = zeros(dim_sys + dim_sys*N, 1);

Kl     = 0.006;
mu     = 0.11;
Yxs_nom= 0.47;
theta  = 0.004;
Yp     = 1.2;
Ki     = 0.1;
Mx     = 0.029;
Kxp    = 0.01;
Kp     = 0.0001;
S0_nom = 400;

%% --------------------- ���ϵͳ ---------------------
x1n = x(1); x2n = x(2); x3n = x(3); x4n = x(4);
dn  = Kl*x1n + x2n;

dx(1) = mu*x1n*x2n/dn - u*x1n/x4n;
dx(2) = -mu*x1n*x2n/(Yxs_nom*dn) - theta*x1n*x2n/(Yp*(x2n+Kp+x2n^2/Ki)) - Mx*x1n + u*(S0_nom-x2n)/x4n;
dx(3) = theta*x1n*x2n/(x2n+Kp+x2n^2/Ki) - Kxp*x3n - u*x3n/x4n;
dx(4) = u;

%% --------------------- ����ϵͳ ---------------------
for k = 1:n_wst
    off = 4 + (k-1)*4;
    Yxs_wst = Yxs_wst_array(k);
    S0_wst  = S0_wst_array(k);
    x1w = x(off+1); x2w = x(off+2); x3w = x(off+3); x4w = x(off+4);
    dw  = Kl*x1w + x2w;
    
    dx(off+1) = mu*x1w*x2w/dw - u*x1w/x4w;
    dx(off+2) = -mu*x1w*x2w/(Yxs_wst*dw) - theta*x1w*x2w/(Yp*(x2w+Kp+x2w^2/Ki)) - Mx*x1w + u*(S0_wst-x2w)/x4w;
    dx(off+3) = theta*x1w*x2w/(x2w+Kp+x2w^2/Ki) - Kxp*x3w - u*x3w/x4w;
    dx(off+4) = u;
end

%% --------------------- �����ȷ��� ---------------------
for i = 1:N
    Idx0 = dim_sys + (i-1)*dim_sys;
    
    %% ---------- ��������� ----------
    DX11 = mu*x2n^2/dn^2 - u/x4n;
    DX12 = mu*Kl*x1n^2/dn^2;
    DX14 = u*x1n/x4n^2;

    DX21 = -mu*x2n^2/(Yxs_nom*dn^2) - theta*x2n/(Yp*(x2n+Kp+x2n^2/Ki)) - Mx;
    DX22 = -mu*Kl*x1n^2/(Yxs_nom*dn^2) - theta*x1n*(Kp-x2n^2/Ki)/(Yp*(x2n+Kp+x2n^2/Ki)^2) - u/x4n;
    DX24 = -u*(S0_nom-x2n)/x4n^2;

    DX31 = theta*x2n/(x2n+Kp+x2n^2/Ki);
    DX32 = theta*x1n*(Kp-x2n^2/Ki)/(x2n+Kp+x2n^2/Ki)^2;
    DX33 = -Kxp - u/x4n;
    DX34 = u*x3n/x4n^2;

    if i == Index
        dx(Idx0+1) = DX11*x(Idx0+1) + DX12*x(Idx0+2) + DX14*x(Idx0+4) - x1n/x4n;
        dx(Idx0+2) = DX21*x(Idx0+1) + DX22*x(Idx0+2) + DX24*x(Idx0+4) + (S0_nom-x2n)/x4n;
        dx(Idx0+3) = DX31*x(Idx0+1) + DX32*x(Idx0+2) + DX33*x(Idx0+3) + DX34*x(Idx0+4) - x3n/x4n;
        dx(Idx0+4) = 1;
    else
        dx(Idx0+1) = DX11*x(Idx0+1) + DX12*x(Idx0+2) + DX14*x(Idx0+4);
        dx(Idx0+2) = DX21*x(Idx0+1) + DX22*x(Idx0+2) + DX24*x(Idx0+4);
        dx(Idx0+3) = DX31*x(Idx0+1) + DX32*x(Idx0+2) + DX33*x(Idx0+3) + DX34*x(Idx0+4);
        dx(Idx0+4) = 0;
    end

    %% ---------- ���������ȣ���ȫ����ԭ�棬�޴��� ----------
    for k = 1:n_wst
        off = 4 + (k-1)*4;
        Yxs_wst = Yxs_wst_array(k);
        S0_wst  = S0_wst_array(k);
        x1w = x(off+1); x2w = x(off+2); x3w = x(off+3); x4w = x(off+4);
        dw  = Kl*x1w + x2w;

        DX11w = mu*x2w^2/dw^2 - u/x4w;
        DX12w = mu*Kl*x1w^2/dw^2;
        DX14w = u*x1w/x4w^2;

        DX21w = -mu*x2w^2/(Yxs_wst*dw^2) - theta*x2w/(Yp*(x2w+Kp+x2w^2/Ki)) - Mx;
        DX22w = -mu*Kl*x1w^2/(Yxs_wst*dw^2) - theta*x1w*(Kp-x2w^2/Ki)/(Yp*(x2w+Kp+x2w^2/Ki)^2) - u/x4w;
        DX24w = -u*(S0_wst-x2w)/x4w^2;

        DX31w = theta*x2w/(x2w+Kp+x2w^2/Ki);
        DX32w = theta*x1w*(Kp-x2w^2/Ki)/(x2w+Kp+x2w^2/Ki)^2;
        DX33w = -Kxp - u/x4w;
        DX34w = u*x3w/x4w^2;

        if i == Index
            dx(Idx0+off+1) = DX11w*x(Idx0+off+1) + DX12w*x(Idx0+off+2) + DX14w*x(Idx0+off+4) - x1w/x4w;
            dx(Idx0+off+2) = DX21w*x(Idx0+off+1) + DX22w*x(Idx0+off+2) + DX24w*x(Idx0+off+4) + (S0_wst-x2w)/x4w;
            dx(Idx0+off+3) = DX31w*x(Idx0+off+1) + DX32w*x(Idx0+off+2) + DX33w*x(Idx0+off+3) + DX34w*x(Idx0+off+4) - x3w/x4w;
            dx(Idx0+off+4) = 1;
        else
            dx(Idx0+off+1) = DX11w*x(Idx0+off+1) + DX12w*x(Idx0+off+2) + DX14w*x(Idx0+off+4);
            dx(Idx0+off+2) = DX21w*x(Idx0+off+1) + DX22w*x(Idx0+off+2) + DX24w*x(Idx0+off+4);
            dx(Idx0+off+3) = DX31w*x(Idx0+off+1) + DX32w*x(Idx0+off+2) + DX33w*x(Idx0+off+3) + DX34w*x(Idx0+off+4);
            dx(Idx0+off+4) = 0;
        end
    end
end
end