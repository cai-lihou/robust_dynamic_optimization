clear all
clc

global T N x0
global lb ub u0 k

u0 = 1;
T = 40;
N = 20;
x0 = [1 0.2 0.001 250];
lb = zeros(1, N);
ub = 10 * ones(1, N);
U_0 = u0 * ones(1, N);
k = 0;
r = 4;
epsilon_act = 1e-3;
epsilon_sat = 1e-3; 
epislon_g0 = 0.001;    
epislon_g = epislon_g0;
T_Dis = 0:1:40;
H = cputime;

% ===================== ���������� =====================
total_nominal = 0;       
total_robust_loops = 0;
total_robust_iter = 0;
% ======================================================

% options = optimoptions('fmincon', ...
%     'SpecifyObjectiveGradient', true, ...
%     'SpecifyConstraintGradient', true, ...
%     'Algorithm', 'sqp', ...
%     'MaxFunctionEvaluations', 10000, ...
%     'ConstraintTolerance', 1e-8, ...
%     'OptimalityTolerance', 1e-6, ...
%     'FunctionTolerance', 1e-10, ...
%     'StepTolerance', 1e-12);
options = optimoptions('fmincon', ...
    'SpecifyObjectiveGradient', true, ...
    'SpecifyConstraintGradient', true, ...
    'CheckGradients', false, ...   % ��������������� MATLAB �Ա�һ��������ݶȶԲ���
    'FiniteDifferenceType', 'central', ... %�Դ�Ϊ��׼
    'Algorithm', 'sqp', ...
    'MaxFunctionEvaluations', 10000, ...
    'ConstraintTolerance', 1e-8, ...
    'OptimalityTolerance', 1e-4, ...
    'StepTolerance', 1e-12);
% options = optimset('GradConstr','on','Algorithm','sqp','MaxFunEvals',10000);
% ��һ�ε��� fmincon
[u, fmin,inf_flag,OUTPUT,lambda,cost_grad] = fmincon(@(u)costfunction(u),U_0,[],[],[],[],lb,ub,@(u)pathconstraints(u,T_Dis,epislon_g),options);
total_nominal = total_nominal + 1;

c=-1;
while c<=0
    c=-1;

    if inf_flag == -2
        epislon_g = epislon_g/r;
        c=-5;
        total_nominal = total_nominal + 1;
    end

    if c==-1
        k=k+1;
        [gmax,tmax,tout,xout] = LLP_events(u);
        if gmax <= 0
            cost_gradient_PCDP = cost_grad;
            multi_PCDP = lambda.ineqnonlin;
            [d, ceq, Gc, Gceq] = pathconstraints(u,T_Dis,epislon_g);
            h = numel(d);
            d1=[d(1:h-2*N)-epislon_g d(h-2*N+1:h)];
            m =0;
            for j=1:h
                if multi_PCDP(j)*d1(j)<-multi_PCDP(j)*epsilon_act
                    c=-5;
                else
                    m=m+1;
                end
            end
            stationarity_val = norm(cost_gradient_PCDP + Gc * multi_PCDP);
            fprintf('  >> KKT Check: m=%d/%d, Stat Norm=%e\n', m, h, stationarity_val);

            if ((m==h)&&(stationarity_val<=epsilon_sat))==1
                fprintf('  >> CONVERGED! Found approximate KKT point.\n');
                u_local=u;
                f_local=fmin;
                c=3;
            else
                fprintf('  >> Not KKT point. Reducing Epsilon_g.\n');
                epislon_g = epislon_g/r;
                c=-5;
            end
        end

        if gmax > 0
            T_Dis = [T_Dis tmax];
            c=-4;
            total_nominal = total_nominal + 1;
        end
    end

    if (c==-5 || c==-4)==1
        Start_Point = u;
        [u, fmin,inf_flag,OUTPUT,lambda,cost_grad] = fmincon(@(u)costfunction(u),Start_Point,[],[],[],[],lb,ub,@(u)pathconstraints(u,T_Dis,epislon_g),options);
        total_nominal = total_nominal + 1;
    end
end
u_norm=u_local;
clear functions
pause(0.1);

fprintf('\n===================================================\n');
fprintf('          ³������������Ż�����\n');
fprintf('===================================================\n');

wst_params = [];
max_violation_worst = 1;

while max_violation_worst > 0
    total_robust_loops = total_robust_loops + 1;

    [best_worst, max_violation_worst,iter_worst] = LLP_PP(u_local);
    fprintf('�Լ��Υ�� = %.6e\n', max_violation_worst);
    total_robust_iter = total_robust_loops + iter_worst;
    if max_violation_worst <= 0
        fprintf('? ³����������Լ��Υ��\n');
        break;
    end

    fprintf('?? ���������\n');
    wst_params = [wst_params; best_worst];

    [u_robust, f_robust, iter_r, epsilon_robust] = run_robust_optimization(wst_params);
    total_robust_iter = total_robust_iter + iter_r;

    u_local = u_robust;
    clear functions;
end

%% ===================== ����ͳ�� =====================
fprintf('\n===================================================\n');
fprintf('              ? ��������ͳ�ƣ���������\n');
fprintf('===================================================\n');
fprintf('? ����Ż���������    = %d\n', total_nominal);
fprintf('? ³���Ż���������    = %d\n', total_robust_iter);
fprintf('---------------------------------------------------\n');
fprintf('? �㷨���Ż���������  = %d\n', total_nominal + total_robust_iter);
fprintf('===================================================\n');

fprintf('\n����³������Ŀ�꣺%.6f\n', f_robust);
TIME = cputime - H;
fprintf('�ܺ�ʱ��%.2f ��\n', TIME);

%% ===================== ���Ʒֶγ����������� =====================
dt = T / N;
t_seg = 0:dt:T;
u_opt = u_local;

figure('Color','w','Position',[100,100,800,400]);
stairs(t_seg, [u_opt, u_opt(end)], 'b-', 'LineWidth', 2);
grid on; box on;
xlabel('ʱ�� t','FontSize',12,'FontWeight','bold');
ylabel('�������� u(t)','FontSize',12,'FontWeight','bold');
title('���ŷֶγ�����������','FontSize',14,'FontWeight','bold');
xlim([0, T]);


save('all_results_my.mat');

fprintf('\n? ���н���ѱ���Ϊ MATLAB ԭ���ļ���\n');
fprintf('   �� all_results_my.mat\n');
fprintf('   ֱ���� load ���ܴ��������ݣ�\n');