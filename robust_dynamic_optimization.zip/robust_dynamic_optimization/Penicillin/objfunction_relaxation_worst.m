function [f_worst, g_worst] = objfunction_relaxation_worst(uvec, VL, VU, A1, A2, ...
    T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst)

[f0_w, g0_w] = objfunction_local_worst(uvec, ...
    T_worst,N_worst,x0_worst,n_states_worst,n_params_worst,U_SEG_worst);
S0 = uvec(1);
Yx = uvec(2);

f_worst = f0_w + A1*(VL(1)-S0)*(VU(1)-S0) + A2*(VL(2)-Yx)*(VU(2)-Yx);
g_worst = g0_w + [A1*(VL(1)+VU(1)-2*S0);
                   A2*(VL(2)+VU(2)-2*Yx)];
end