function [cieq, ceq, G_cieq, G_ceq] = robust_path_constraints(u,T_Dis,epsilon_g, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array)
CvpGrd = 0:T/N:T;
N_TD = numel(T_Dis);
NStat = 4 + 4 * n_wst;

y0 = x0_all;
y0 = [y0, zeros(1, NStat*N)];

x_TD = zeros(N_TD, length(y0));
cieq_path = zeros(1, 2*N_TD);
G_path    = zeros(N, 2*N_TD);

OdeOption = odeset('RelTol',1e-10,'AbsTol',1e-10,'MaxStep',(T/N)/50);

current_idx = 1;

for i = 1:N
    t_start = CvpGrd(i);
    t_end   = CvpGrd(i+1);
    
    t_need = T_Dis(T_Dis >= t_start & T_Dis <= t_end);
    if isempty(t_need)
        [~, x_tmp] = ode45(@(t,x) robust_ode_sensitivity(t,x,u(i),i,N, Yxs_wst_array, S0_wst_array, n_wst), [t_start, t_end], y0, OdeOption);
        y0 = x_tmp(end,:);
        continue;
    end
    
    [~, x_all] = ode45(@(t,x) robust_ode_sensitivity(t,x,u(i),i,N, Yxs_wst_array, S0_wst_array, n_wst), t_need, y0, OdeOption);
    
    for p = 1:length(t_need)
        x_TD(current_idx, :) = x_all(p,:);
        current_idx = current_idx + 1;
    end
    
    y0 = x_all(end,:);
end

for j = 1:N_TD
    cieq_path(1, 2*j-1) = x_TD(j, 2) - 0.5 + epsilon_g;
    G_path(:, 2*j-1)   = x_TD(j, NStat+2 : NStat : NStat+NStat*N);
    
    cieq_path(1, 2*j)   = x_TD(j, 6) - 0.5 + epsilon_g;
    G_path(:, 2*j)      = x_TD(j, NStat+6 : NStat : NStat+NStat*N);
end

cieq = cieq_path;
for i = 1:N
    cieq = [cieq, u(i)-10, -u(i)];
end

grad_bounds = zeros(N, 2*N);
for i = 1:N
    grad_bounds(i, 2*i-1) = 1;
    grad_bounds(i, 2*i)   = -1;
end

G_cieq = [G_path, grad_bounds];
ceq = [];
G_ceq = [];
end