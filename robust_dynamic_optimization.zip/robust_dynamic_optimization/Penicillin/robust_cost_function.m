function [objval,Gobj] = robust_cost_function(u, T, N, x0_all, n_wst, Yxs_wst_array, S0_wst_array)
CvpGrd = 0:T/N:T;
NStat = 4 + 4 * n_wst;
y0 = x0_all;
y0 = [y0,zeros(1,NStat*N)];
OdeOption = odeset('RelTol',1e-9,'AbsTol',1e-9);

for i = 1:N
    [t,x]=ode45(@(t,x)robust_ode_sensitivity(t,x,u(i),i,N, Yxs_wst_array, S0_wst_array, n_wst),...
        CvpGrd(i:i+1),y0,OdeOption);
    y0=x(end,:);
end

objval = -x(end,3);
Gobj = -x(end,8+3:8:8*N+8)';
end