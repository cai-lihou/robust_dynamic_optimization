function dx = OdeSnstv_VDPO(t,x,Dec,Index,N,CurGrd)%CurGrd时间当前网格�?
%%动�?�系统定义，包含求梯度用的附加变�?
%   此处显示详细说明

 %3 states+10 components of constraint gradient, i.e., dx1/dp1,dx1/dp2, since path constraint only
                   %contains x1, calculating gradients of x1 wrt,
                   %p1,...,p10 is enough

                   
dx = zeros(4+4*N,1);% 系统维数�?3，灵敏度方程中，3个状态需要对N个控制向量参数分别求梯度

u = Dec;

Kl=0.006;
mu=0.11;
Yxs=0.47;
theta=0.004;
Yp=1.2;
Ki=0.1;
Mx=0.029;
Kxp=0.01;
Kp=0.0001;
S0=400;


dx(1)=mu*x(1)*x(2)/(Kl*x(1)+x(2))-u*x(1)/x(4);  %define ode
dx(2)=-mu*x(1)*x(2)/(Yxs*(Kl*x(1)+x(2)))-theta*x(1)*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx*x(1)+u*(S0-x(2))/x(4);
dx(3)=theta*x(1)*x(2)/(x(2)+Kp+x(2)^2/Ki)-Kxp*x(3)-u*x(3)/x(4);
dx(4)=u;


for i = 1:N
    Idx0 = 4 + (i-1)*4;
    if i == Index
        DX11=mu*x(2)^2/(Kl*x(1)+x(2))^2-u/x(4);
        DX12=mu*Kl*x(1)^2/(Kl*x(1)+x(2))^2;
        DX14=u*x(1)/x(4)^2;
     dx(Idx0+1) = DX11*x(Idx0+1) + DX12*x(Idx0+2) + DX14*x(Idx0+4)-x(1)/x(4);
        DX21=-mu*x(2)^2/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx;
        DX22=-mu*x(1)^2*Kl/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(1)*(Kp-x(2)^2/Ki)/(Yp*(x(2)+Kp+x(2)^2/Ki)^2)-u/x(4);
        DX24=-u*(S0-x(2))/x(4)^2;
     dx(Idx0+2) = DX21*x(Idx0+1) + DX22*x(Idx0+2) + DX24*x(Idx0+4)+(S0-x(2))/x(4); 
        DX31=theta*x(2)/(x(2)+Kp+x(2)^2/Ki);
        DX32=theta*x(1)*(Kp-x(2)^2/Ki)/(x(2)+Kp+x(2)^2/Ki)^2;
        DX33=-Kxp-u/x(4);
        DX34=u*x(3)/x(4)^2;
     dx(Idx0+3) = DX31*x(Idx0+1) + DX32*x(Idx0+2) + DX33*x(Idx0+3) + DX34*x(Idx0+4)-x(3)/x(4);
     dx(Idx0+4) =1;
    else
        DX11=mu*x(2)^2/(Kl*x(1)+x(2))^2-u/x(4);
        DX12=mu*Kl*x(1)^2/(Kl*x(1)+x(2))^2;
        DX14=u*x(1)/x(4)^2;
     dx(Idx0+1) = DX11*x(Idx0+1) + DX12*x(Idx0+2) + DX14*x(Idx0+4);
        DX21=-mu*x(2)^2/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx;
        DX22=-mu*x(1)^2*Kl/(Yxs*(Kl*x(1)+x(2))^2)-theta*x(1)*(Kp-x(2)^2/Ki)/(Yp*(x(2)+Kp+x(2)^2/Ki)^2)-u/x(4);
        DX24=-u*(S0-x(2))/x(4)^2;
     dx(Idx0+2) = DX21*x(Idx0+1) + DX22*x(Idx0+2) + DX24*x(Idx0+4); 
        DX31=theta*x(2)/(x(2)+Kp+x(2)^2/Ki);
        DX32=theta*x(1)*(Kp-x(2)^2/Ki)/(x(2)+Kp+x(2)^2/Ki)^2;
        DX33=-Kxp-u/x(4);
        DX34=u*x(3)/x(4)^2;
     dx(Idx0+3) = DX31*x(Idx0+1) + DX32*x(Idx0+2) + DX33*x(Idx0+3) + DX34*x(Idx0+4);
     dx(Idx0+4) =0;
    end
    
end

end
