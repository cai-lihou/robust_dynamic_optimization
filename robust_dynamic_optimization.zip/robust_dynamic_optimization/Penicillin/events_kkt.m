function [value,isterminal,direction] = events_kkt(t,x,p,u) %events function
%%
Kl=0.006;
mu=0.11;
Yxs=0.47;
theta=0.004;
Yp=1.2;
Ki=0.1;
Mx=0.029;
Kxp=0.01;
Kp=0.0001;
S0=400;
%%
H=-mu*x(1)*x(2)/(Yxs*(Kl*x(1)+x(2)))-theta*x(1)*x(2)/(Yp*(x(2)+Kp+x(2)^2/Ki))-Mx*x(1)+u*(S0-x(2))/x(4); %derivative of path constraint g|||����u�ǳ�������g��t�ĵ�������x��t�ĵ���  
%H=u; %derivative of path constraint g   
value = [x(6)-x(5); H]; %values of event functions gmax-g
isterminal = [1; 1];    %stop itegration when crossing zeros
direction = [0; 0];    %both side crossing
