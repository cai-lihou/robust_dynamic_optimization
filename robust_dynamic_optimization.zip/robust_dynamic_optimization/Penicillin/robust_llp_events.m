function [Gmax, Tmax, tout, xout] = robust_llp_events(u, T, N, x0_all, Yxs_wst_array, S0_wst_array, n_wst)
CvpGrd = 0:T/N:T;

y0 = x0_all;
nState = length(y0);
y0 = [y0, zeros(1, nState*N)];

tout = [];
xtraj_full = [];

for i = 1:N
    t_seg = [CvpGrd(i), CvpGrd(i+1)];
    [t_seg_out, x_seg_out] = ode45(...
        @(t,x) robust_ode_sensitivity(t, x, u(i), i, N, Yxs_wst_array, S0_wst_array, n_wst), ...
        t_seg, y0);
    tout = [tout; t_seg_out];
    xtraj_full = [xtraj_full; x_seg_out];
    y0 = x_seg_out(end, :);
end

xout = xtraj_full(:, 1:8);

g_nom = xout(:, 2) - 0.5;
g_wst = xout(:, 6) - 0.5;

[Gmax1, idx1] = max(g_nom);
[Gmax2, idx2] = max(g_wst);

if Gmax1 > Gmax2
    Gmax = Gmax1;
    Tmax = tout(idx1);
else
    Gmax = Gmax2;
    Tmax = tout(idx2);
end
end